<?php 
session_start();
?>

<?php

    $DB = new PDO("mysql:host=localhost;port=3306;dbname=wastemgt", 'root','');
    $DB->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);


    $error = "";

if ($_SERVER['REQUEST_METHOD'] == "POST") {

      //save to DB
      $arr['email'] = $_POST['email'];
      $arr['password'] = hash('sha1', $_POST['password']);

      $query = "SELECT * FROM users WHERE email = :email && password = :password LIMIT 1";
        $stm = $DB->prepare($query);

        if ($stm) {
          $check = $stm->execute($arr);
          if ($check){
            $data = $stm -> fetchAll(PDO::FETCH_ASSOC);
            if(is_array($data) && count($data) > 0)
            {
              $_SESSION['myid'] = $data[0]['userid'];
              $_SESSION['myname'] = $data[0]['name'];
              $_SESSION['myemail'] = $data[0]['email'];
              $_SESSION['myrank'] = $data[0]['rank'];
            } else {
                $error = "Wrong credentials";
                // header("Location: signup.php"); 
            }
          }

          if ($error == "") {

            header("Location: index.php");
            die;
          }
    }
    
}

?>





<html>
    <head>
        <title>Waste management system</title>
        <!-- icons link -->
        <link rel="stylesheet" href="./css/fontawesome.min.css">
    <!-- page styling link call -->
        <link rel="stylesheet" href="./css/bootstrap.min.css">
        <!-- page styling link call -->
        <!-- <link rel="stylesheet" href="../css/main.css"> -->
        <link rel="stylesheet" href="./css/login-signup.css">
    </head>
    <body>

    <?php
    if ($error != "") {
        echo "<div class='alert alert-danger'>$error</div><br><br>";
    }
    ?>

    <h1 class="text-danger">Login</h1>

<section class="header-top row p-3" style="width: 400px;">
    <form action="" method="POST" class="needs-validation" validate>

        <div class="my-2">
            <label for="validationCustomUsername" class="form-label">Email</label>
            <div class="input-group has-validation">
            <span class="input-group-text" id="inputGroupPrepend">@</span>
            <input type="email" name="email" class="form-control" id="validationCustomUsername" aria-describedby="inputGroupPrepend" required>
            <div class="invalid-feedback">
                Please input your email address.
            </div>
            </div>
        </div>

        <div class="my-2">
            <label for="validationCustomUsername" class="form-label">Password</label>
            <div class="input-group has-validation">
            <span class="input-group-text" id="inputGroupPrepend"><i class="fas fa-lock"></i></span>
            <input type="password" name="password" class="form-control" id="validationCustomUsername" aria-describedby="inputGroupPrepend" required>
            <div class="invalid-feedback">
                Please choose a Password.
            </div>
            </div>
        </div>
        <div class="col-12">
            <button class="btn btn-primary" type="submit">Login</button>
        </div>
    <a href="signup.php" class="sign-up-activate btn btn-default my-4" style="z-index: 1000;">Not a user? <span id="sign-up-call">Click here to Sign Up</span></a>
    </form>

</section>

    <script src="./js/fontawesome.min.js"></script>
    <script src="./js/bootstrap.min.js"></script>
    <script src="./js/main.js"></script>

    <script>
        var sendFooterYr = new Date();
        document.getElementById("footer-year-current").innerHTML = sendFooterYr.getFullYear();
    </script>
    </body>
</html>