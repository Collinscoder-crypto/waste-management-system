<?php session_start(); ?>
<?php include_once('./access.php') ?>
<?php 
    $DB = new PDO("mysql:host=localhost;port=3306;dbname=wastemgt", 'root','');
    $DB->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);



    
    $id = $_GET['id'] ?? null;
    if (!$id) {
        header('Location: events.php');
    }
    $statement = $DB ->prepare('SELECT * FROM events WHERE id= :id');
    $statement->bindValue(':id', $id);
    $statement -> execute();
    $events = $statement -> fetch();

// echo '<pre>';
// var_dump($events);
// echo '</pre>';





?>







?>
<?php
include ('./patials/header.php');
?>



<nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top">
  <div class="container-fluid">
    <a class="navbar-brand text-warning" href="index.php">Wastee</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarTogglerDemo02">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link" href="index.php">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="events.php">Events</a>
        </li>
        
        <li class="nav-item">
          <a class="nav-link" href="../users/index.php">Users</a>
        </li>
        <!-- <li class="nav-item">
          <a class="nav-link btn btn-danger btn-sm text-light" href="logout.php">Logout</a>
        </li> -->
      </ul>
      <h5 class="text-danger d-flex mx-2"><?php
        if (isset($_SESSION['myname'])){
          echo "<span class='text-secondary px-3'>Username: </span>  " . $_SESSION['myname'];
        }
        ?></h5>
        <?php if (access('ADMIN', false)){
          echo'<a class="nav-link btn btn-outline-warning" href="./admin/index.php" style="font-weight: 600;" style="font-weight: 600;">Admin Page</a>';
        } ?>
        <a class="nav-link btn btn-danger btn-sm text-light" href="logout.php">Logout</a>
    </div>
  </div>
</nav>


    <h1 class="my-5" style="font-weight: 900;">The service you want to request for</h1>


  <div class="pickup-card chose-event">
    <header><img src="./admin/<?php echo $events['image'] ?>" style="width: 100%;" alt=""></header>
    <div class="content">
      <div class="sub-cont">
      <h5 class="text-light py-3 px-3 my-3 bg-secondary"><span style="margin-right: 100px; color: whitesmoke;">Type of pick up:</span><span class="text-danger" style="text-transform: uppercase; font-weight: 900; text-shadow: 0 0 5px whitesmoke;"><?php echo $events['type'];?></span></h5>
      <div class="info text-dark">
        <?php echo $events['type']?> Waste materials include:
        <br>
        <span style="text-align: center;">
        <?php echo $events['description']?>
        </span>
      </div>
      </div>
      <!-- <form>
      </form> -->
    </div>
  </div>
  
  
    <script src="./js/bootstrap.min.js"></script>
</body>
</html>