<?php
  session_start();
?>



<?php
    $DB = new PDO("mysql:host=localhost;port=3306;dbname=wastemgt", 'root','');
    $DB->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    
    $id = $_GET[$_SESSION['myid']];

    // echo '<pre>';
    // var_dump($_SESSION['myid']);
    // echo '</pre>';
    // exit();
    
    $id =$_SESSION['myid'];
    // echo '<pre>';
    // var_dump($id);
    // echo '</pre>';
    // exit();
            
            $statement =$DB ->prepare('SELECT * FROM users WHERE id= :id');
            $statement->bindValue(':id', $id);
            $statement->execute();
            
            $subs = $statement->fetch(PDO::FETCH_ASSOC);
            
            // echo '<pre>';
            // var_dump($subs);
            // echo '</pre>';
            // exit();
            
            
            // function randomString($n){
            //     $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
            //     $str = '';
            
            //     for ($i = 0; $i < $n; $i++){
            //         $index = rand(0, strlen($characters)-1);
            //         $str .= $characters[$index];
            //     }
            
            //     return $str;
            // }
            
            $errors = [];
            
            $subscribe = $subs['subscribe'];
            
            if ($_SERVER['REQUEST_METHOD'] === 'POST'){
                $subscribe = $_POST['subscribe'];
                $arr['name'] = $_POST['name'];
                $arr['email'] = $_POST['email'];
                $arr['password'] = hash('sha1', $_POST['password']);
                $arr['rank'] = "user";

                $query = "INSERT INTO users (userid,name,email,password,rank) 
                                VALUES ( :userid, :name, :email, :password, :rank)";
                    $stm = $DB->prepare($query);

                    if ($stm) {
                    $check = $stm -> execute($arr);

                    if (!$check) {
                        $error = "could not save to the database";
                        // header("Location: signup.php");
                    }

                    if ($error == "") {
                        header("Location: login.php");
                        die;
                    }
                }
                
                
            }

?>











<?php
require_once('./patials/header.php');
?>


<nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top" style="display: none;"> 
  <div class="container-fluid">
    <a class="navbar-brand text-warning" href="index.php" style="font-weight: 800;">Wastee</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarTogglerDemo02">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="#" style="font-weight: 600;">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link " href="./admin/index.php" style="font-weight: 600;" style="font-weight: 600;">Admin Page</a>
        </li>
        <!-- <li class="nav-item">
          <a class="nav-link btn btn-danger btn-sm text-light" href="logout.php">Logout</a>
        </li> -->
      </ul>
      <h5 class="text-danger d-flex mx-2"><?php
        if (isset($_SESSION['myname'])){
          echo "<span class='text-secondary px-3'>Username: </span>  " . $_SESSION['myname'];
        }
        ?></h5>
        <a class="nav-link btn btn-secondary mx-2 btn-sm text-light" href="./admin/index.php">Admin Page</a>
        <a class="nav-link btn btn-danger btn-sm text-light" href="logout.php">Logout</a>
    </div>
  </div>
</nav>
  <header class="top-page_header">
        <div class="hero text-dark">
            <h4>Welcome to</h4>
            <h1 class="name-0">Waste Management System </h1>
            <p class="content">
                Lorem ipsum dolor sit amet consectetur, adipisicing elit. Quisubsdam, illum quaerat. Vitae nobis ab incidunt cupiditate sequi quis repudiandae velit.
            </p>
            
        </div>

    </header>
    <main class="content-main-sec">
        <!-- -------------------------- Right side navigation panel -->
        <div class="aside-nav-sec">
            <h1 class="aside-subs">Notifications</h1>
            <ul class="row">
                
                <!-- ----------------- single buton sec-------- -->
                <li class="col col-md-2 col-lg-12 m-1">
                    <a href="events.php" type="button" class="btn btn-light button">One time Pick up</a>
                </li>
                
                <!-- ----------------- single buton sec-------- -->
                <li class="col col-md-2 col-lg-12 m-1">
                    <a href="events.php" type="button" class="btn btn-light button">Schedule a pickup</a>
                </li>
                
                <!-- ----------------- single buton sec-------- -->
                <li class="col col-md-2 col-lg-12 m-1">
                    <a href="Profile.php" type="button" class="btn btn-light button">My Profile</a>
                </li>
                
                <!-- ----------------- single buton sec-------- -->
                <li class="col col-md-2 col-lg-12 m-1">
                    <a href="events.php" type="button" class="btn btn-light button">Truck on duty</a>
                </li>
                
                <!-- ----------------- single buton sec-------- -->
                <li class="col col-md-2 col-lg-12 m-1">
                    <a href="#" type="button" class="btn btn-light button">My Payments</a>
                </li>
                
                <!-- ----------------- single buton sec-------- -->
                <li class="col col-md-2 col-lg-12 m-1">
                    <a href="events.php" type="button" class="btn btn-light button">
                        <img src="./assets/couple-1030744_1920.jpg" alt="" class="thumb" style="width:100px;">
                        <div class="description">
                            <h6>Truck on duty</h6>
                        </div>
                    </a>
                </li>
                
            </ul>
        </div>

        <!-- -------------------------- Main content -home sectin-side -->
        <section class="main-content-grids">
            <section class="container-group-tiles row">
                
                <!-- ----------------- single card -->
                <div class="tile col col-xs-12 col-sm-12 col-lg-6">
                <!-- <div class="tile col col-sm-12 col-lg-6"> -->
                    <div class="container row">
                        
                        <img src="./assets/images/user icon.png" alt="" class="col" style="width:50px; filter:grayscale(0);">
                        <div class="col content">
                            <h5>Dear <?php
                                    if (!isset($_SESSION['myname'])){
                                    echo "<h6 class='subs' style='font-size: 10px;'>Guest, please first login to subscribe<h6>";
                                }else{
                                    echo $_SESSION['myname'] . ',';
                                }
                                ?>
                                </h5>
                            <hr>
                            <p>
                                Please click the button below to join the lucky people to enjoy our wonderful services. We would like to inform you that that the pay,ents will be done through mobile money.
                            </p>
                        </div>
                    </div>
                </div>
                
                <!-- ----------------- single card -->
                <div class="tile col col-xs-12 col-sm-12 col-lg-6 container">
                    <!-- <form action="" method="POST" class="needs-validation" validate>

                        <div class="my-2">
                            <label for="validationCustomUsername" class="form-label">Email</label>
                            <div class="input-group has-validation">
                            <span class="input-group-text" id="inputGroupPrepend">@</span>
                            <input type="email" name="email" class="form-control" id="validationCustomUsername" aria-describedby="inputGroupPrepend" required>
                            <div class="invalid-feedback">
                                Please input your email address.
                            </div>
                            </div>
                        </div>

                        <div class="my-2">
                            <label for="validationCustomUsername" class="form-label">Password</label>
                            <div class="input-group has-validation">
                            <span class="input-group-text" id="inputGroupPrepend"><i class="fas fa-lock"></i></span>
                            <input type="password" name="password" class="form-control" id="validationCustomUsername" aria-describedby="inputGroupPrepend" required>
                            <div class="invalid-feedback">
                                Please choose a Password.
                            </div>
                            </div>
                        </div>
                        <div class="col-12">
                            <button class="btn btn-primary" type="submit">Order Pickup</button>
                        </div>
                    </form> -->
                    <form action="" method="post">
                    <input type="text" name="subscribe" value="yes" style="visibility: hidden;"><br>
                    <h6 class="p-2 text-warning">Make sure you have your location activated!</h6>
                    <p class="text-secondary">
                        Dear customer, we would like to inform you that subscription only lasts 30 days.
                        please incase of any complaints, dont hesitate to complain
                    </p>

                        <button type="submit" class="btn btn-success btn-lg" style="width: 100%;">Subscribe</button>
                    </form>

                
                </div>
                
            </section>
        </section>
    </main>






    <?php
require_once('./patials/footer.php')
?>