<?php
  session_start();
?>

<?php
    include_once('../access.php');
    access("ADMIN");

    if (!isset($_SESSION['myname'])){
    header('location: ../login.php');
    }
?>

<?php
require_once('./patials/header.php')
?>


<nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top">
  <div class="container-fluid">
    <a class="navbar-brand text-warning" href="index.php">Wastee</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarTogglerDemo02">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="../index.php">View Page</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Link</a>
        </li>
        
        <li class="nav-item">
          <a class="nav-link" href="../users/index.php">Users</a>
        </li>
        <!-- <li class="nav-item">
          <a class="nav-link btn btn-danger btn-sm text-light" href="logout.php">Logout</a>
        </li> -->
      </ul>
      <h5 class="text-danger d-flex mx-2"><?php
        if (isset($_SESSION['myname'])){
          echo "<span class='text-secondary px-3'>Username: </span>  " . $_SESSION['myname'];
        }
        ?></h5>
        <a class="nav-link btn btn-danger btn-sm text-light" href="../logout.php">Logout</a>
    </div>
  </div>
</nav>
  <header class="top-page_header">
        <div class="hero text-dark">
            <h4>Welcome to</h4>
            <h1 class="name-0">Waste Management System </h1>
            <p class="content">
                Lorem ipsum dolor sit amet consectetur, adipisicing elit. Quibusdam, illum quaerat. Vitae nobis ab incidunt cupiditate sequi quis repudiandae velit.
            </p>
            
        </div>

    </header>
    <main class="content-main-sec">
        <!-- -------------------------- Right side navigation panel -->
        <div class="aside-nav-sec">
            <h1 class="aside-title">Notifications</h1>
            <ul class="row">
                
                <!-- ----------------- single buton sec-------- -->
                <li class="col col-md-2 col-lg-12 m-1">
                    <a href="events.php" type="button" class="btn btn-light button">One time Pick up</a>
                </li>
                
                <!-- ----------------- single buton sec-------- -->
                <li class="col col-md-2 col-lg-12 m-1">
                    <a href="events.php" type="button" class="btn btn-light button">Schedule a pickup</a>
                </li>
                
                <!-- ----------------- single buton sec-------- -->
                <li class="col col-md-2 col-lg-12 m-1">
                    <a href="Profile.php" type="button" class="btn btn-light button">My Profile</a>
                </li>
                
                <!-- ----------------- single buton sec-------- -->
                <li class="col col-md-2 col-lg-12 m-1">
                    <a href="events.php" type="button" class="btn btn-light button">Truck on duty</a>
                </li>
                
                <!-- ----------------- single buton sec-------- -->
                <li class="col col-md-2 col-lg-12 m-1">
                    <a href="#" type="button" class="btn btn-light button">My Payments</a>
                </li>
                
                <!-- ----------------- single buton sec-------- -->
                <li class="col col-md-2 col-lg-12 m-1">
                    <a href="events.php" type="button" class="btn btn-light button">
                        <img src="./assets/couple-1030744_1920.jpg" alt="" class="thumb" style="width:100px;">
                        <div class="description">
                            <h6>Truck on duty</h6>
                        </div>
                    </a>
                </li>
                
            </ul>
        </div>

        <!-- -------------------------- Main content -home sectin-side -->
        <section class="main-content-grids">
            <section class="container-group-tiles row">
                
                <!-- ----------------- single card -->
                <!-- <a href="events.php" type="button" class="btn button tile col col-xs-12 col-sm-12 col-lg-6"> -->
                
                <a href="events.php" type="button" class="btn button tile amin-cont-edit">
                <!-- <div class="tile col col-sm-12 col-lg-6"> -->
                    <div class="container row">
                        
                        <img src="./assets/images/events.png" alt="" class="col" style="width:50px;">
                        <div class="col content">
                            <h5>Events & Schedules</h5>
                            <hr>
                            <p>
                                <h6 class="text-secondary">Add an event of which your clients will choose from in order to select whether they need thier rubish to be picked</h6>
                            </p>
                        </div>
                    </div>
                </a>
                
                <!-- ----------------- single card -->
                <a href="reports.php" type="button" class="btn button tile amin-cont-edit">
                <!-- <div class="tile col col-sm-12 col-lg-6"> -->
                    <div class="container row">
                        
                        <img src="./assets/images/flag-removebg-preview.png" alt="" class="col" style="width:50px;">
                        <div class="col content">
                            <h5>Report Missed Pickups</h5>
                            <hr>
                            <p>
                                If you have any queries of the Lorem ipsum dolor sit amet consectetur adipisicing elit. Distinctio, assumenda.
                            </p>
                        </div>
                    </div>
                </a>
                
                <!-- ----------------- single card -->
                <a href="#" type="button" class="btn button tile amin-cont-edit">
                <!-- <div class="tile col col-sm-12 col-lg-6"> -->
                    <div class="container row">
                        
                        <img src="./assets/images/payment.png" alt="" class="col" style="width:50px;">
                        <div class="col content">
                            <h5>Payment & Invoices</h5>
                            <hr>
                            <p>
                                If you have any queries of the Lorem ipsum dolor sit amet consectetur adipisicing elit. Distinctio, assumenda.
                            </p>
                        </div>
                    </div>
                </a>
                
                <!-- ----------------- single card -->
                <a href="#" type="button" class="btn button tile amin-cont-edit">
                <!-- <div class="tile col col-sm-12 col-lg-6"> -->
                    <div class="container row">
                        
                        <img src="./assets/images/track_2.png" alt="" class="col" style="width:50px;">
                        <div class="col content">
                            <h5>View Service Requests</h5>
                            <hr>
                            <p>
                                If you have any queries of the Lorem ipsum dolor sit amet consectetur adipisicing elit. Distinctio, assumenda.
                            </p>
                        </div>
                    </div>
                </a>
            </section>
        </section>
    </main>






    <?php
require_once('./patials/footer.php')
?>