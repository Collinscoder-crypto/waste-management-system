<?php
  session_start();
?>

<?php
    include_once('../access.php');
    access("ADMIN");

    if (!isset($_SESSION['myname'])){
    header('location: ../login.php');
    }
?>

<?php 
    $DB = new PDO("mysql:host=localhost;port=3306;dbname=wastemgt", 'root','');
    $DB->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);




// --------------------------- search section ------------------
$search = $_GET['search'] ?? null;

if ($search){
  $statement = $DB->prepare('SELECT * FROM adminquery WHERE title LIKE :title ORDER BY date DESC');
  $statement->bindValue(':title', "%$search%");
}else{
  $statement = $DB->prepare('SELECT * FROM adminquery ORDER BY date DESC');
}

// --------------------------- search section ------------------

$statement -> execute();
$adminquerys = $statement -> fetchAll(PDO:: FETCH_ASSOC);

// echo '<pre>';
// var_dump($adminquerys);
// echo '</pre>';
// exit;

?>




<?php
require_once('./patials/header.php')
?>


  <header class="top-page_header">
        <div class="hero text-dark">
            <h4>Welcome to</h4>
            <h1 class="name-0">Waste Management System </h1>
            <p class="content">
                Lorem ipsum dolor sit amet consectetur, adipisicing elit. Quibusdam, illum quaerat. Vitae nobis ab incidunt cupiditate sequi quis repudiandae velit.
            </p>
            
        </div>

    </header>

    <main class="content-main-sec">
        <!-- -------------------------- Right side navigation panel -->
        <div class="aside-nav-sec">
            <h1 class="aside-title">Notifications</h1>
            <ul class="row">
                
                <!-- ----------------- single buton sec-------- -->
                <li class="col col-md-2 col-lg-12 m-1">
                    <a href="events.php" type="button" class="btn btn-light button">One time Pick up</a>
                </li>
                
                <!-- ----------------- single buton sec-------- -->
                <li class="col col-md-2 col-lg-12 m-1">
                    <a href="events.php" type="button" class="btn btn-light button">Schedule a pickup</a>
                </li>
                
                <!-- ----------------- single buton sec-------- -->
                <li class="col col-md-2 col-lg-12 m-1">
                    <a href="Profile.php" type="button" class="btn btn-light button">My Profile</a>
                </li>
                
                <!-- ----------------- single buton sec-------- -->
                <li class="col col-md-2 col-lg-12 m-1">
                    <a href="events.php" type="button" class="btn btn-light button">Truck on duty</a>
                </li>
                
                <!-- ----------------- single buton sec-------- -->
                <li class="col col-md-2 col-lg-12 m-1">
                    <a href="#" type="button" class="btn btn-light button">My Payments</a>
                </li>
                
                <!-- ----------------- single buton sec-------- -->
                <li class="col col-md-2 col-lg-12 m-1">
                    <a href="events.php" type="button" class="btn btn-light button">
                        <img src="./assets/couple-1030744_1920.jpg" alt="" class="thumb" style="width:100px;">
                        <div class="description">
                            <h6>Truck on duty</h6>
                        </div>
                    </a>
                </li>
                
            </ul>
        </div>

        <!-- -------------------------- Main content -home sectin-side -->
        <section class="main-content-grids">
            <section class="container-group-tiles row">


      <?php foreach ($adminquerys as $adminquery):?>
                <!-- ----------------- single message card -->
                <div class="message-slot-flex">
                    <a href="report-slot.php?id=<?php echo $adminquery['id'];?>" type="button" class="btn button tile message-slot">
                        <!-- <div class="tile col col-sm-12 col-lg-6"> -->
                            <div class="container-msg">
                            <div class="logo"><i class="fas fa-envelope"></i></div>
                                
                                <div class="names">
                                    <h5><?php echo $adminquery['username'];?></h5>
                                </div>
                                <div class="rank"> <h6><?php echo $adminquery['rank'];?></h6></div>
                                <div class="time"> <h6><?php echo $adminquery['date'];?></h6></div>
                            </div>
                    </a>
                        <form action="delete-rep.php" method="post">
                            <input type="hidden" name="id" value="<?php echo $adminquery['id'] ?>">
                            <button type="submit" class="btn text-light p-2 btn-secondary" title="Delete this message"><i class="fas fa-trash"></i></button>
                        </form>
                </div>
      <?php endforeach; ?>
                
                
            </section>
        </section>
    </main>






    <?php
require_once('./patials/footer.php')
?>