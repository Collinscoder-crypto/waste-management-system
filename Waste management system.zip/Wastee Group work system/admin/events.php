
<?php
    // include_once('../access.php');
    // access("ADMIN");

    // if (!isset($_SESSION['myname'])){
    // header('location: ../index.php');
    // }
?>
<?php 

    $DB = new PDO("mysql:host=localhost;port=3306;dbname=wastemgt", 'root','');
    $DB->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// echo "<pre>";
// var_dump($_SERVER);
// echo "</pre>";
// exit;

// echo "<pre>";
// var_dump($_POST);
// echo "</pre>";
// exit; 
// echo $_SERVER['REQUEST_METHOD'] . '<br>';

// echo "<pre>";
// var_dump($_FILES);
// echo "</pre>";


function randomString($n){
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $str = '';

    for ($i = 0; $i < $n; $i++){
        $index = rand(0, strlen($characters)-1);
        $str .= $characters[$index];
    }

    return $str;
}

$errors = [];

$type = '';
$company = '';
$price = '';

if (!is_dir('images')) {
    mkdir('images');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST'){
    $type = $_POST['type'];
    $company = $_POST['company'];
    $price = $_POST['price'];
    $datemade = $_POST['datemade'];
    $contact = $_POST['contact'];
    $description = $_POST['description'];
    $date = date('Y-m-d H:i:s');

    if (!$type){
        $errors[] = 'Event type is required';
    }

    if (!$price){
        $errors[] = 'Event price is required';
    }
    
    if (empty($errors)) {

        $image = $_FILES['image'] ?? null;

        $imagePath = '';
        if ($image && $image['tmp_name']){
            $imagePath = 'images/'.randomString(8).'/'.$image['name'];

            mkdir(dirname($imagePath));
            move_uploaded_file($image['tmp_name'], $imagePath);
        }
        
        $statement = $DB->prepare("INSERT INTO events (type, image, company, price, created_date, contact, day, description)
                    VALUES (:type, :image, :company, :price, :date, :contact, :datemade, :description)");
        
        $statement->bindValue(':datemade', $datemade);
        $statement->bindValue(':type', $type);
        $statement->bindValue(':image', $imagePath);
        $statement->bindValue(':company', $company);
        $statement->bindValue(':price', $price);
        $statement->bindValue(':date', $date);
        $statement->bindValue(':contact', $contact);
        $statement->bindValue(':description', $description);
        
        $statement->execute();
    }
    
}



?>




<?php
include ('./patials/header.php');
?>



<nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top">
  <div class="container-fluid">
    <a class="navbar-brand text-warning" href="index.php">Wastee</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarTogglerDemo02">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link" href="index.php">Admin Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="../index.php">View Page</a>
        </li>
        
        <li class="nav-item">
          <a class="nav-link" href="../users/index.php">Users</a>
        </li>
        <!-- <li class="nav-item">
          <a class="nav-link btn btn-danger btn-sm text-light" href="logout.php">Logout</a>
        </li> -->
      </ul>
      <h5 class="text-danger d-flex mx-2"><?php
        if (isset($_SESSION['myname'])){
          echo "<span class='text-secondary px-3'>Username: </span>  " . $_SESSION['myname'];
        }
        ?></span>
        <a class="nav-link btn btn-danger btn-sm text-light" href="../logout.php">Logout</a>
    </div>
  </div>
</nav>

<h1 class="header-barner px-5" style="font-weight: 900;">Create New Event</h1>

<button onclick="goBack()" class="btn btn-outline-dark mx-3"><b> Back </b></button>

<form action="" method="post" enctype="multipart/form-data" class="add-content-form">

<?php if (!empty($errors)): ?>

<div class="alert alert-danger">
    <?php foreach ($errors as $error): ?>
    <p><?php echo $error; ?></p>
    <?php endforeach; ?>
</div>

<?php endif; ?>
<div class="form-group">
    <label>Pickup header image</label><br>
    <input type="file" name="image">
</div>

<div class="form-group">
    <label>Event Type</label>
    <input type="text" name="type" class="form-control" value="<?php echo $type ?>">
</div>

<div class="form-group">
    <label>Company on duty</label>
    <input class="form-control" name="company" value="<?php echo $company ?>">
</div>

<div class="form-group">
    <label> Company Contact</label>
    <input class="form-control" name="contact">
</div>

<div class="form-group">
    <label>Pickup Price</label>
    <input type="number" name="price" step=".01" class="form-control" value="<?php echo $price ?>">
</div>

<div class="form-group">
    <label>Pickup Day of the week</label>
    <input type="date" name="datemade" step=".01" class="form-control">
</div>

<div class="form-group">
    <label>Product Description</label>
    <p class="text-small text-warning">Please tell the clients what kind or trush is going to be picked up by the company</p>
    <textarea class="form-control" name="description" required></textarea>
</div>

<button type="submit" class="btn btn-primary">Submit</button>
</form> 

  
    <script src="./js/bootstrap.min.js"></script>
    <script src="./js/bootstrap.min.js"></script>
    <script>
    function goBack(){
        window.history.back();
    }
    </script>
</body>
</html>