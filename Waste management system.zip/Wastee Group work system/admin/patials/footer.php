
    <footer class="bottom-footer text-dark">
        <p class="footer-cont p-3">Copyright &copy; Waste Management System - <span id="footer-year-current"></span> All rights reserved</p>
    </footer>
    
    <script src="./js/fontawesome.min.js"></script>
    <script src="./js/bootstrap.min.js"></script>
    <script src="./js/main.js"></script>

    <script>
        var sendFooterYr = new Date();
        document.getElementById("footer-year-current").innerHTML = sendFooterYr.getFullYear();
    </script>
    </body>
</html>