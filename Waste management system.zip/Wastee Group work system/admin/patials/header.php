
<html>
    <head>
        <title>Waste Management System</title>
        <!-- icons link -->
        <link rel="stylesheet" href="./css/fontawesome.min.css">
    <!-- page styling link call -->
        <link rel="stylesheet" href="./css/bootstrap.min.css">
        <!-- page styling link call -->
        <!-- <link rel="stylesheet" href="../css/main.css"> -->
        <link rel="stylesheet" href="./css/style.css">
    </head>
    <body>
        

<nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top">
  <div class="container-fluid">
    <a class="navbar-brand text-warning" href="index.php">Wastee</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarTogglerDemo02">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="../index.php">View Page</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="reports.php">Reports</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Link</a>
        </li>
        
        <li class="nav-item">
          <a class="nav-link" href="../users/index.php">Users</a>
        </li>
        <!-- <li class="nav-item">
          <a class="nav-link btn btn-danger btn-sm text-light" href="logout.php">Logout</a>
        </li> -->
      </ul>
      <h5 class="text-danger d-flex mx-2"><?php
        if (isset($_SESSION['myname'])){
          echo "<span class='text-secondary px-3'>Username: </span>  " . $_SESSION['myname'];
        }
        ?></h5>
        <a class="nav-link btn btn-danger btn-sm text-light" href="../logout.php">Logout</a>
    </div>
  </div>
</nav>