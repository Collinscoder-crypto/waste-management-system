<html>
    <head>
        <title>Uganda Cancer Platform</title>
        <!-- icons link -->
        <link rel="stylesheet" href="../css/fontawesome.min.css">
    <!-- page styling link call -->
        <link rel="stylesheet" href="./css/bootstrap.min.css">
        <!-- page styling link call -->
        <!-- <link rel="stylesheet" href="../css/main.css"> -->
        <link rel="stylesheet" href="../css/login-signup.css">
        <style>
            @font-face {
            font-family: poppins;
            src: url(../fonts/Poppins/Poppins-Regular.ttf);
            }

            *{
                padding: 0;
                margin: 0;
                box-sizing: border-box;
            }

            html{
                scroll-behavior: smooth;
            }

            body{
                width: 100%;
                background: white;
                overflow-x: hidden;
                font-family: poppins;
                background-image: url('./assets/couple-1030744_1920.jpg');
                background-size: cover;
                background-repeat: no-repeat;
                background-attachment: fixed;
                background-position: center;
                position: relative;
            }

            body::before{
                content: '';
                width: 100%;
                height: 100%;
                position: fixed;
                top: 0;
                left: 0;
                background: linear-gradient(220deg, rgba(7, 163, 7, 0.863), rgba(146, 24, 24, 0.733), transparent);
                z-index: 1;
                opacity: .5;
            }

            p{
                font-size: 14px;
                color: rgba(0, 0, 0, 0.7);
                padding: 5px;
                line-height: 20px;
            }

            .mobile-toggle-but{
                z-index: 50000;
                position: fixed;
                top: 0;
                right: 0;
                padding: 10px;
                margin: 10px;
                background: gold;
                cursor: pointer;
            }

            .header-top{
                width: 100%;
                height: 100vh;;
                position: relative;
            }


            @media (max-width: 760px) {
                .header-top{
                    width: 100%;
                    position: relative;
                    display: flex;
                    flex-direction: column;
                    align-items: center;
                }
            }

                /* padding: 5px;
                background-image: url('./assets/couple-1030744_1920.jpg');
                background-size: cover;
                background-position: center;
                position: relative;
            }

            .header-top::before{
                content: '';
                width: 100%;
                height: 100%;
                position: absolute;
                top: 0;
                left: 0;
                background: linear-gradient(220deg, rgba(7, 163, 7, 0.863), rgba(146, 24, 24, 0.733), transparent);
                z-index: 1;
                opacity: .5;
            } */

            .header-top .top_nav-sec{
                width: 100%;
                position: fixed;
                top: 0;
                left: 0;
                right: 0;
                display: flex;
                flex-direction: column;
                justify-content: center;
                align-items: center;
                background: whitesmoke;
                transform: translateY(-100%);
                color: gray;
                transition: .5s;
                z-index: 40000;
            }

            .header-top #top_nav-sec.Navactive{
                display: block;
            }

            .header-top .top_nav-sec .logo-sec{
                width: 100%;
                height: 80px;
            }

            .header-top .top_nav-sec .logo-sec img{
                width: 100%;
                height: 100%;
                object-fit: fill;
            }

            .header-top .top_nav-sec  .links{
                list-style: none;
                line-height: 40px;
            }

            .header-top .top_nav-sec  .links li a{
                text-decoration: none;
                color: gray;
                transition: .5s;
            }

            .header-top .top_nav-sec  .links li:hover{
                text-decoration: underline;
            }

            .header-top .top_nav-sec  .links .search-form-sec{
                display: inline-flex;
                align-items: center;
            }

            .header-top .top_nav-sec  .links .search-form-sec form{
                transition: .5s;
                display: none;
                box-shadow: 0 0 10px gray;
                padding: 0 5px;
            }

            .header-top .top_nav-sec  .links .search-form-sec form input{
                padding: 5px;
                font-size: 14px;
                color: rgba(0, 0, 0, 0.8);
                font-weight: 300;
                outline: none;
                border: none;
                box-shadow: 0 0 10px gray;
            }

            .header-top .top_nav-sec  .links .search-form-sec form button{
                padding: 5px;
                font-size: 14px;
                outline: none;
                background: gray;
                border: none;
                color: white;
            }

            .header-top .top_nav-sec  .links .search-form-sec .search-cl{
                cursor: pointer;
            }

            .header-top .top_nav-sec  .links .search-form-sec .search-cl:hover{
                color: skyblue;
                text-decoration: overline;
            }

            /* ------------------ Nav media queries */
            @media (min-width: 760px) {
                
                .mobile-toggle-but{
                    display: none;
                }

                .header-top .top_nav-sec{
                    width: 100%;
                    position: fixed;
                    top: 0;
                    left: 0;
                    right: 0;
                    display: flex;
                    flex-direction: row;
                    justify-content: space-around;
                    align-items: center;
                    background: whitesmoke;
                    transform: translateY(0);
                    color: gray;
                    transition: .5s;
                    z-index: 40000;
                }

                .header-top .top_nav-sec .logo-sec{
                    width: 50px;
                    height: 50px;
                    transform: translateX(-100px);
                }

                .header-top .top_nav-sec .logo-sec img{
                    width: 100%;
                    height: 100%;
                    object-fit: fill;
                }

                .header-top .top_nav-sec  .links{
                    width: 60%;
                    justify-content: space-around;
                    list-style: none;
                    line-height: 40px;
                    display: flex;
                }

                .header-top .top_nav-sec  .links li a{
                    text-decoration: none;
                    color: skyblue;
                    text-shadow: 0 0 1px 1px black;
                    transition: .5s;
                }

                .header-top .top_nav-sec  .links li:hover{
                    text-decoration: underline;
                }

                .header-top .top_nav-sec  .links .search-form-sec{
                    display: inline-flex;
                    align-items: center;
                }

                .header-top .top_nav-sec  .links .search-form-sec form{
                    transition: .5s;
                    display: none;
                    box-shadow: 0 0 10px gray;
                    padding: 0 5px;
                }

                .header-top .top_nav-sec  .links .search-form-sec form input{
                    padding: 5px;
                    font-size: 14px;
                    color: rgba(0, 0, 0, 0.8);
                    font-weight: 300;
                    outline: none;
                    border: none;
                    box-shadow: 0 0 10px gray;
                }

                .header-top .top_nav-sec  .links .search-form-sec form button{
                    padding: 5px;
                    font-size: 14px;
                    outline: none;
                    background: gray;
                    border: none;
                    color: white;
                }

                .header-top .top_nav-sec  .links .search-form-sec .search-cl{
                    cursor: pointer;
                }

                .header-top .top_nav-sec  .links .search-form-sec .search-cl:hover{
                    color: skyblue;
                    text-decoration: overline;
                }
            }

            .header-top .hero{
                width: 90%;
                /* background: rgba(135, 207, 235, 0.5); */
                padding: 10px;
                z-index: 10;
                display: flex;
                flex-direction: column;
                align-items: center;
                position: relative;
            }

            .header-top .hero h4, .header-top .hero h1{
                color: rgba(153, 31, 31, 0.9);
            }

            .header-top .hero h4{
                color: rgba(65, 26, 26, 0.9);
            }

            .header-top .hero h1{
                font-size: 100%;
            }

            .header-top .hero p{
                /* background:rgba(153, 31, 31, 0.562); */
                color: rgba(0, 0, 0, 0.781);
                font-size: 13px;
                margin: 20px auto;
            }

            .header-top .hero a{
                padding: unset;
                margin: 10px;
                /* border: 1px solid rgba(153, 31, 31, 0.562); */
                outline: none;
                color: white;
                text-decoration: none;
                transition: .5s;
                border-radius: 5px;
                font-size: 14px;
            }
            .header-top .hero a span{
                color:rgba(153, 31, 31, 0.562);
                text-decoration: underline;
            }

            .header-top .hero a:hover{
                text-decoration: underline;
            }

            .header-top .hero .more{
                padding: 10px 20px;
                margin: 5px;
                background: rgba(245, 245, 245, 0.712);
                color: black;
            }

            .header-top .hero .more:hover{
                background: rgba(153, 31, 31, 0.562);
                color: white;
            }

            .header-top .hero .consult{
                padding: 10px 20px;
                margin: 5px;
                background:rgba(153, 31, 31, 0.562);
                object-fit: cover;
            }

            .header-top .hero .consult:hover{
                background: transparent;
                color: rgba(153, 31, 31, 0.562);
            }

            .header-top .sign-sec-home {
                width: 80%;
                background-color: rgba(0, 0, 0, 0.5);
                z-index: 10000;
                position: relative;
            }

            .header-top .sign-sec-home form{
                width: 100%;
                margin: 10px auto;
                padding: 10px;
            }

            .header-top .sign-sec-home form h1{
                font-size: 20px;
                color: rgba(245, 245, 245, 0.712);
            }

            .header-top .sign-sec-home form hr{
                margin-bottom: 20px;
                height: 2px;
                background-color: rgba(245, 245, 245, 0.2);
                border: none;
            }

            .header-top .sign-sec-home form .inputs-grouped{
                display: flex;
                justify-content: space-between;
                width: 100%;
            }

            .header-top .sign-sec-home form .inputs-grouped input{
                padding: 5px;
                width: 45%;
                height: 30px;
                position: relative;
            }
            .header-top .sign-sec-home form .inputs-grouped .show-password{
                width: 45%;
                position: relative;
            }

            .header-top .sign-sec-home form .inputs-grouped .show-password input{
                width: 100%;
                padding: 5px;
                height: 30px;
                padding-right: 30px;
            }

            .header-top .sign-sec-home form .inputs-grouped .show-password .eye-button{
                position: absolute;
                right: 0;
                top: 15%;
                background-color: rgb(109, 109, 250);
                color: white;
                padding: 2.5px;
                z-index: 5;
                cursor: pointer;
            }

            .header-top .sign-sec-home form button{
                width: 150px;
                padding: 5px;
                border: 1px solid whitesmoke;
                outline: none;
                color: whitesmoke;
                font-weight: 700;
                font-size: 15px;
                background-color: rgba(135, 207, 235, 0.171);
            }

            .header-top .sign-sec-home form button:hover{
                background-color: rgba(135, 207, 235, 0.5);
            }

            .sign-up-activate{
                font-size: 15px;
                padding: 5px;
                color: rgba(186, 223, 238, 0.753);
                font-weight: 500;
                width: 100%;
                background-color: rgba(186, 223, 238, 0.2);
            }

            .sign-up-activate #sign-up-call{
                font-size: 14px;
                color: rgb(219, 215, 215);
                font-weight: 500;
                cursor: pointer;
                padding: 0 5px;
                text-decoration: underline;
            }

            /* --------------------- Sign up section  */

            .header-top .sign-up-sec-home {
                width: 500px;
                background-color: rgba(0, 0, 0, 0.5);
                z-index: 10000;
                transition: .5s;
            }

            @media (max-width: 760px) {
                .header-top .sign-sec-home {
                    width: 100%;
                    background-color: rgba(0, 0, 0, 0.5);
                    z-index: 10000;
                    position: relative;
                }

                .header-top .sign-up-sec-home{
                    width: 100%;
                    background-color: rgba(0, 0, 0, 0.5);
                    z-index: 10000;
                    position: relative;
                    margin: 20px auto;
                }
            }

            .header-top .sign-up-sec-home form{
                width: 100%;
                margin: 10px auto;
                padding: 10px;
            }

            .header-top .sign-up-sec-home form h1{
                font-size: 20px;
                color: rgba(245, 245, 245, 0.712);
            }

            .header-top .sign-up-sec-home form #telphone-sibn-up{
                width: 80%;
                height: 30px;
                margin: auto;
            }

            .header-top .sign-up-sec-home form hr{
                margin-bottom: 20px;
                height: 2px;
                background-color: rgba(245, 245, 245, 0.2);
                border: none;
            }

            .header-top .sign-up-sec-home form .inputs-grouped{
                display: flex;
                flex-direction: column;
                justify-content: space-around;
                width: 100%;
                margin: 10px 0;
                padding: 5px 0;
            }

            .header-top .sign-up-sec-home form .inputs-grouped input{
                padding: 5px;
                width: 45%;
                height: 30px;
                position: relative;
            }
            .header-top .sign-up-sec-home form .inputs-grouped .show-password{
                width: 80%;
                position: relative;
                margin: auto;
            }

            .header-top .sign-up-sec-home form .inputs-grouped .show-password input{
                width: 100%;
                padding: 5px;
                height: 30px;
                margin: 5px 0;
                padding-right: 30px;
            }

            .header-top .sign-up-sec-home form .inputs-grouped .show-password .eye-button{
                position: absolute;
                right: 0;
                top: 15%;
                background-color: rgb(109, 109, 250);
                color: white;
                padding: 2.5px;
                z-index: 5;
                cursor: pointer;
            }

            .header-top .sign-up-sec-home form button{
                width: 150px;
                padding: 5px;
                border: 1px solid whitesmoke;
                outline: none;
                color: whitesmoke;
                font-weight: 700;
                font-size: 15px;
                background-color: rgba(135, 207, 235, 0.171);
            }

            .header-top .sign-up-sec-home form button:hover{
                background-color: rgba(135, 207, 235, 0.5);
            }

            .sign-up-activate{
                font-size: 15px;
                padding: 5px;
                color: rgba(186, 223, 238, 0.753);
                font-weight: 500;
                width: 100%;
                background-color: rgba(186, 223, 238, 0.2);
            }

            .sign-up-activate #sign-up-call{
                font-size: 14px;
                color: rgb(219, 215, 215);
                font-weight: 500;
                cursor: pointer;
                padding: 0 5px;
                text-decoration: underline;
            }

            .reset-header{
                color: rgba(245, 245, 245, 0.7);
                font-size: 15px;
                text-align: center;
                font-weight: 500;
            }

            @media (min-width: 780px) {
                .header-top .hero{
                    width: 50%;
                    transform: unset;
                    transition: .7s;
                }
                
                .header-top .hero:hover{
                    background: rgba(135, 207, 235, 0.5);
                }
                
                .header-top .hero h4, .header-top .hero h1{
                    color: rgba(153, 31, 31, 0.9);
                }
                
                .header-top .hero h4{
                    color: rgba(65, 26, 26, 0.9);
                }
                
                .header-top .hero .name-0{
                    font-size: 2.5em;
                    background:rgba(245, 245, 245, 0.7);
                    width: 100%;
                    text-align: center;
                    color:rgba(153, 31, 31, 0.562);
                }
                
                .header-top .hero p{
                    /* background:rgba(153, 31, 31, 0.562); */
                    color: rgba(0, 0, 0, 0.781);
                    font-size: 14px;
                    margin: 20px auto;
                }
                
            }

            .needs-validation{
                width: 500px;
                height: 500px;
                background-color: rgba(0, 0, 0, 0.5);
                z-index: 99900;
            }

            .needs-validation label{
                color: whitesmoke;
            }

            .needs-validation input{
                width: 100%;
            }





            /* -------------------------------------------- footer section --- */
            .footer-cont{
                position: absolute;
                bottom: 0;
                left: 0;
                width: 100%;
                margin-bottom: -40px;
                background: brown;
                color: white;
            }

        </style>
    </head>
    <body>