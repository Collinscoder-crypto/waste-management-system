<?php 
    $DB = new PDO("mysql:host=localhost;port=3306;dbname=wastemgt", 'root','');
    $DB->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$id = $_POST['id'] ?? null;

if (!$id) {
    header('Location: ../events.php');
    exit;
}

$statement = $DB->prepare("DELETE FROM events WHERE id=:id");
$statement->bindValue(':id', $id);
$statement->execute();

header('Location: ../events.php');

?>