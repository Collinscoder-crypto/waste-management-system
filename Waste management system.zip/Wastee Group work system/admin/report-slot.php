<?php
  session_start();
?>

<?php
    include_once('../access.php');
    access("ADMIN");

    if (!isset($_SESSION['myname'])){
    header('location: ../login.php');
    }
?>

<?php 
    $DB = new PDO("mysql:host=localhost;port=3306;dbname=wastemgt", 'root','');
    $DB->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);




    
    $id = $_GET['id'] ?? null;
    if (!$id) {
        header('Location: adminquery.php');
    }
    $statement = $DB ->prepare('SELECT * FROM adminquery WHERE id= :id');
    $statement->bindValue(':id', $id);
    $statement -> execute();
    $adminquery = $statement -> fetch();

// echo '<pre>';
// var_dump($adminquerys);
// echo '</pre>';
// exit;

?>




<?php
require_once('./patials/header.php')
?>


  <header class="top-page_header">
        <div class="hero text-dark">
            <h4>Welcome to</h4>
            <h1 class="name-0">Waste Management System </h1>
            <p class="content">
                Lorem ipsum dolor sit amet consectetur, adipisicing elit. Quibusdam, illum quaerat. Vitae nobis ab incidunt cupiditate sequi quis repudiandae velit.
            </p>
            
        </div>

    </header>

    <main class="content-main-sec">
        <!-- -------------------------- Right side navigation panel -->
        <div class="aside-nav-sec" style="display: none;">
            <h1 class="aside-title">Notifications</h1>
            <ul class="row">
                
                <!-- ----------------- single buton sec-------- -->
                <li class="col col-md-2 col-lg-12 m-1">
                    <a href="adminquery.php" type="button" class="btn btn-light button">One time Pick up</a>
                </li>
                
                <!-- ----------------- single buton sec-------- -->
                <li class="col col-md-2 col-lg-12 m-1">
                    <a href="adminquery.php" type="button" class="btn btn-light button">Schedule a pickup</a>
                </li>
                
                <!-- ----------------- single buton sec-------- -->
                <li class="col col-md-2 col-lg-12 m-1">
                    <a href="Profile.php" type="button" class="btn btn-light button">My Profile</a>
                </li>
                
                <!-- ----------------- single buton sec-------- -->
                <li class="col col-md-2 col-lg-12 m-1">
                    <a href="adminquery.php" type="button" class="btn btn-light button">Truck on duty</a>
                </li>
                
                <!-- ----------------- single buton sec-------- -->
                <li class="col col-md-2 col-lg-12 m-1">
                    <a href="#" type="button" class="btn btn-light button">My Payments</a>
                </li>
                
                <!-- ----------------- single buton sec-------- -->
                <li class="col col-md-2 col-lg-12 m-1">
                    <a href="adminquery.php" type="button" class="btn btn-light button">
                        <img src="./assets/couple-1030744_1920.jpg" alt="" class="thumb" style="width:100px;">
                        <div class="description">
                            <h6>Truck on duty</h6>
                        </div>
                    </a>
                </li>
                
            </ul>
        </div>

        <!-- -------------------------- Main content -home sectin-side -->
        <section class="main-content-grids">
            <section class="container-group-tiles row">

            <div class="pickup-card chose-message">
            <div class="content">
                <div class="sub-cont">
                    <div class="creds bg-dark">
                        <h5 class="text-light py-3 px-3 my-3 bg-secondary">
                        <span style="margin-right: 100px; color: whitesmoke;">This message is from:</span><span class="text-danger" style="text-transform: uppercase; font-weight: 900; text-shadow: 0 0 5px whitesmoke;"><?php echo $adminquery['username'];?></span></h5>
                        <h6 class="text-light"><span class="mx-2" style="font-size: 12px;">User type:</span> <span style="margin-right: 100px;"><?php echo $adminquery['rank']?></span></h6>
                        <h6 class="text-light"><span class="mx-2" style="font-size: 12px;">User email:</span> <span style="margin-right: 100px;"><?php echo $adminquery['email']?></span></h6>
                    </div>
                <div class="text-dark">
                    <p>
                        <?php echo $adminquery['message']?>
                    </p>
                </div>
                </div>
                <!-- <form>
                </form> -->
            </div>
            </div>
                
            </section>
        </section>
    </main>






    <?php
require_once('./patials/footer.php')
?>