<?php 
    $DB = new PDO("mysql:host=localhost;port=3306;dbname=wastemgt", 'root','');
    $DB->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$id = $_POST['id'] ?? null;
// var_dump($id);
// exit;

if (!$id) {
    header('Location: reports.php');
    exit;
}

$statement = $DB->prepare("DELETE FROM adminquery WHERE id=:id");
$statement->bindValue(':id', $id);
$statement->execute();

header('Location: reports.php');

?>