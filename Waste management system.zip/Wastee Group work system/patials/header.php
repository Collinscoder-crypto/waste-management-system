
<html>
    <head>
        <title>Waste Management System</title>
        <!-- icons link -->
        <link rel="stylesheet" href="./css/fontawesome.min.css">
    <!-- page styling link call -->
        <link rel="stylesheet" href="./css/bootstrap.min.css">
        <!-- page styling link call -->
        <!-- <link rel="stylesheet" href="../css/main.css"> -->
        <link rel="stylesheet" href="./css/style.css">
    </head>
    <body>