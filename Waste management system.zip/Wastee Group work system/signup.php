<?php
    $DB = new PDO("mysql:host=localhost;port=3306;dbname=wastemgt", 'root','');
    $DB->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);


    $error = "";
    function create_userid() {
      $length = rand(4,20);
      $number = "";
      for ($i= 0; $i < $length; $i++) {
        $new_rand = rand(0,9);
        $number = $number . $new_rand;
      }
      return $number;
    }


if ($_SERVER['REQUEST_METHOD'] == "POST") {

      $arr['userid'] = create_userid();
    //   $condition = true;

    //   while ($condition) {
    //     $query = "SELECT id FROM userid = :userid LIMIT 1";
    //     $stm = $DB->prepare($query);

    //     if ($stm){
    //       $check = $stm->execute($arr);
    //       if ($check){
    //         $data = $stm -> fetchAll(PDO::FETCH_ASSOC);

    //         if(is_array($data) && count($data) > 0){
    //           $arr['userid'] = create_userid();
    //           continue;
    //         }
    //       }

    //     }
    //     $condition = false;
    // }

      //save to DB
      $arr['name'] = $_POST['name'];
      $arr['email'] = $_POST['email'];
      $arr['password'] = hash('sha1', $_POST['password']);
      $arr['rank'] = "user";

      $query = "INSERT INTO users (userid,name,email,password,rank) 
                    VALUES ( :userid, :name, :email, :password, :rank)";
        $stm = $DB->prepare($query);

        if ($stm) {
          $check = $stm -> execute($arr);

          if (!$check) {
            $error = "could not save to the database";
            // header("Location: signup.php");
          }

          if ($error == "") {
            header("Location: login.php");
            die;
          }
    }
    
}

?>





<html>
    <head>
        <title>Waste management system</title>
        <!-- icons link -->
        <link rel="stylesheet" href="./css/fontawesome.min.css">
    <!-- page styling link call -->
        <link rel="stylesheet" href="./css/bootstrap.min.css">
        <!-- page styling link call -->
        <!-- <link rel="stylesheet" href="../css/main.css"> -->
        <link rel="stylesheet" href="./css/login-signup.css">
    </head>
    <body>

    <?php
    if ($error != "") {
        echo "<div class='alert alert-danger'>$error</div><br><br>";
    }
    ?>
<!-- <nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top">
  <div class="container-fluid">
    <a class="navbar-brand text-warning" href="index.php">Wastee</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarTogglerDemo02">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="#">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Link</a>
        </li>
        <li class="nav-item">
          <a class="nav-link disabled" href="#" tabindex="-1" aria-disabled="true">Disabled</a>
        </li>
      </ul>
      <form class="d-flex">
        <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
        <button class="btn btn-outline-success" type="submit">Search</button>
      </form>
    </div>
  </div>
</nav> -->
    <h1 class="text-danger">Sign Up</h1>

<section class="header-top row p-3" style="width: 400px;">
    <form action="" method="POST" class="needs-validation" validate>

      <div class="my-2">
        <label for="validationCustomUsername" class="form-label">Username</label>
        <div class="input-group has-validation">
          <span class="input-group-text" id="inputGroupPrepend"><i class="fas fa-user"></i></span>
          <input type="text" name="name" class="form-control" id="validationCustomUsername" aria-describedby="inputGroupPrepend" required>
          <div class="invalid-feedback">
            Please choose a username.
          </div>
        </div>
      </div>

      <div class="my-2">
        <label for="validationCustomUsername" class="form-label">Email</label>
        <div class="input-group has-validation">
          <span class="input-group-text" id="inputGroupPrepend">@</span>
          <input type="email" name="email" class="form-control" id="validationCustomUsername" aria-describedby="inputGroupPrepend" required>
          <div class="invalid-feedback">
            Please input your email address.
          </div>
        </div>
      </div>

      <div class="my-2">
        <label for="validationCustomUsername" class="form-label">Password</label>
        <div class="input-group has-validation">
          <span class="input-group-text" id="inputGroupPrepend"><i class="fas fa-lock"></i></span>
          <input type="password" name="password" class="form-control" id="validationCustomUsername" aria-describedby="inputGroupPrepend" required>
          <div class="invalid-feedback">
            Please choose a Password.
          </div>
        </div>
      </div>
      <div class="col-12">
        <button class="btn btn-primary" type="submit">Register</button>
      </div>

      <a href="login.php" class="btn btn-secondary my-4">Already a user? <span style="color: rgba(245, 245, 245, 0.411);">Login</span></a>
</form>

</section>

    <script src="./js/fontawesome.min.js"></script>
    <script src="./js/bootstrap.min.js"></script>
    <script src="./js/main.js"></script>

    <script>
        var sendFooterYr = new Date();
        document.getElementById("footer-year-current").innerHTML = sendFooterYr.getFullYear();
    </script>
    </body>
</html>