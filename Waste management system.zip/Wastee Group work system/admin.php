<?php 
$pdo = new PDO('mysql:host=localhost;port=3306;dbname=products_crud', 'root', '');
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// echo "<pre>";
// var_dump($_SERVER);
// echo "</pre>";
// exit;

// echo "<pre>";
// var_dump($_POST);
// echo "</pre>";
// exit; 
// echo $_SERVER['REQUEST_METHOD'] . '<br>';

// echo "<pre>";
// var_dump($_FILES);
// echo "</pre>";



$errors = [];

$title = '';
$description = '';
$price = '';

if (!is_dir('images')) {
    mkdir('images');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST'){
    $title = $_POST['title'];
    $description = $_POST['description'];
    $price = $_POST['price'];
    $date = date('Y-m-d H:i:s');

    if (!$title){
        $errors[] = 'Product title is required';
    }

    if (!$price){
        $errors[] = 'Product price is required';
    }
    
    if (empty($errors)) {

        $image = $_FILES['image'] ?? null;

        $imagePath = '';
        if ($image && $image['tmp_name']){
            $imagePath = 'images/'.randomString(8).'/'.$image['name'];

            mkdir(dirname($imagePath));
            move_uploaded_file($image['tmp_name'], $imagePath);
        }
        
        $statement = $pdo->prepare("INSERT INTO products (title, image, description, price, create_date)
                    VALUES (:title, :image, :description, :price, :date)");
        
        $statement->bindValue(':title', $title);
        $statement->bindValue(':image', $imagePath);
        $statement->bindValue(':description', $description);
        $statement->bindValue(':price', $price);
        $statement->bindValue(':date', $date);
        
        $statement->execute();
    }
    
}



?>









<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="./css/bootstrap.min.css">
    <link rel="stylesheet" href="./css/style.css">
    <style>
    form{
        width: 50%;
        position: relative;
        /* top: 50%;
        left: 50%;
        transform: translate(-50%, -50%); */
        background-color: wheat;
        padding: 10px;
    }
    </style>
</head>
<body>
    <h1 style="font-weight: 900;">Create New Product</h1>

        <button onclick="goBack()" class="btn btn-outline-dark"><b> Back </b></button>

    <form action="" method="post" enctype="multipart/form-data">

    <?php if (!empty($errors)): ?>

        <div class="alert alert-danger">
            <?php foreach ($errors as $error): ?>
            <p><?php echo $error; ?></p>
            <?php endforeach; ?>
        </div>

    <?php endif; ?>

        <div class="form-group">
            <label>Product image</label><br>
            <input type="file" name="image">
        </div>
    
        <div class="form-group">
            <label>Product Title</label>
            <input type="text" name="title" class="form-control" value="<?php echo $title ?>">
        </div>
    
        <div class="form-group">
            <label>Product Description</label>
            <textarea class="form-control" name="description" value="<?php echo $description ?>"></textarea>
        </div>
    
        <div class="form-group">
            <label>Product Price</label>
            <input type="number" name="price" step=".01" class="form-control" value="<?php echo $price ?>">
        </div>
    
        <button type="submit" class="btn btn-primary">Submit</button>
</form> 
  
    <script src="./js/bootstrap.min.js"></script>
    <script>
    function goBack(){
        window.history.back();
    }
    </script>
</body>
</html>