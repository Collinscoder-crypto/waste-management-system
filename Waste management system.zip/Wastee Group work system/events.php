<?php session_start(); ?>
<?php include_once('access.php') ?>
<?php 
    $DB = new PDO("mysql:host=localhost;port=3306;dbname=wastemgt", 'root','');
    $DB->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);



// --------------------------- search section ------------------
// $search = $_GET['search'] ?? null;

// if ($search){
//   $statement = $DB->prepare('SELECT * FROM events WHERE title LIKE :title ORDER BY created_date DESC');
//   $statement->bindValue(':title', "%$search%");
// }else{
//   $statement = $DB->prepare('SELECT * FROM events ORDER BY created_date DESC');
// }

// --------------------------- search section ------------------




$statement = $DB->prepare('SELECT * FROM events ORDER BY created_date DESC');
$statement -> execute();
$events = $statement -> fetchAll(PDO:: FETCH_ASSOC);

// echo '<pre>';
// var_dump($events);
// echo '</pre>';  






?>







?>
<?php
include ('./patials/header.php');
?>



<nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top">
  <div class="container-fluid">
    <a class="navbar-brand text-warning" href="index.php">Wastee</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarTogglerDemo02">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link" aria-current="page" href="index.php">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" href="events.php">Events</a>
        </li>
        
        <?php if (access('ADMIN', false)): ?>
          <li class="nav-item">
            <a class="nav-link" href="../users/index.php">Users</a>
          </li>
        <?php endif; ?>
        
      </ul>
      <h5 class="text-danger d-flex mx-2"><?php
        if (isset($_SESSION['myname'])){
          echo "<span class='text-secondary px-3'>Username: </span>  " . $_SESSION['myname'];
        }
        ?></h5>
        <a class="nav-link btn btn-danger btn-sm text-light" href="../logout.php">Logout</a>
    </div>
  </div>
</nav>


    <h1 class="my-5" style="font-weight: 900;">Today's events</h1>


    <?php if (access('ADMIN', false)): ?>
    <p>
      <a href="./admin/events.php" class="btn btn-success">Create new Event</a>
    </p>
      <?php endif; ?>

    <table class="table table-borderless">
    <thead>
      <tr>
        <th style="display: none;">#</th>
        <th>Image</th>
        <th>Title</th>
        <th>Price</th>
        <th>Create Date</th>
          <?php if (access('ADMIN', false)): ?>
            <p>
        <th>Action</th>
            </p>
          <?php endif; ?>
        <th>view</th>
      </tr>
    </thead>
    <tbody>

      <?php foreach ($events as $i => $event):?>
      <tr>

        <th scope="row" style="display: none;"><?php echo $i +1; ?></th>
        <td><img src="./admin/<?php echo $event['image'] ?>" alt="product image" class="product-image-frm-db thumb" style="width: 100px;"></td>
        <td><?php echo $event['type'];?></td>
        <td><?php echo $event['price']?><span class="text-dark" style="font-size: 12px; font-weight: 600;">UgX</span></td>
        <td><?php echo $event['day']?></td>
        <td>
        <div class="btn-group">
          <!-- <a href="update.php?id=<?php echo $event['id']?>" type="button" class="btn btn-primary">Edit</a>

             -->
          <?php if (access('ADMIN', false)): ?>
            <form action="./admin/delete.php" method="post">
              <input type="hidden" name="id" value="<?php echo $event['id'] ?>">
              <p>
                <button type="submit" class="btn btn-danger">Delete</button>
              </p>
          </form>
          <?php endif; ?>

      </div> 
        </td>
        <td>
          <a href="events-op.php?id=<?php echo $event['id']?>" type="button" class="btn btn-primary">Check out</a>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>

<!-- 
  <div class="pickup-card">
    <header><img src="./admin/<?php echo $event['image'] ?>"alt=""></header>
    <div class="content">
      <div class="sub-cont">
      <h5 class="text-secondary"><?php echo $event['type'];?></h5>
      <div class="info text-info">
        Donemestic Waste materials include:
        <br>
        <span class="bg-danger">
          Plustics, foodstuffs, broken objects and all other waste materials that cannot couse harm to human life in regarding to clinical objects
        </span>
      </div>
      </div>
    </div>
  </div> -->
  
  
    <script src="./js/bootstrap.min.js"></script>
</body>
</html>