"# waste-management-system" 
