<?php
session_start();


$DB = new PDO("mysql:host=localhost;port=3306;dbname=wastemgt", 'root','');
$DB->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$id = $_SESSION['myid'];
// var_dump($id);
// exit;


// $query = "SELECT email FROM users WHERE userid = :userid LIMIT 1";
$query = "SELECT * FROM users WHERE userid = :userid LIMIT 1";
$statement = $DB->prepare($query);

$statement->bindValue(':userid', $id);
$statement -> execute();
$user = $statement -> fetch();


// var_dump($_POST);
// $query = "SELECT * FROM adminquery WHERE userid = :userid LIMIT 1";



$errors = [];

$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST'){
    $username = $_POST['username'];
    $email = $_POST['email'];
    $rank = $_POST['rank'];
    $userid = $id;
    $message = $_POST['message'];
    $date = date('Y-m-d H:i:s');

    if (!$message){
        $errors[] = 'Event message is required';
    }
        
        $statement = $DB->prepare("INSERT INTO adminquery (username,  email, rank, date, message, userid)
                    VALUES (:username, :email, :rank, :date, :message, :userid)");
        
        $statement->bindValue(':userid', $userid);
        $statement->bindValue(':username', $username);
        $statement->bindValue(':email', $email);
        $statement->bindValue(':rank', $rank);
        $statement->bindValue(':date', $date);
        $statement->bindValue(':message', $message);
        
        $statement->execute();
        // $success_text = "Your message has been sent";
        header('Location: index.php');
    }
    












// echo $user['rank'];
// var_dump($user);
// echo $user['email'];

// var_dump($user);