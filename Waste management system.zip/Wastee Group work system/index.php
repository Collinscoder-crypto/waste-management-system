<?php
include_once('check-creds.php');
?>

<?php
    // if (!isset($_SESSION['myname'])){
    // header('location: login.php');
    // }
?>

<?php
require_once('access.php');
require_once('./patials/header.php');
?>


<nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top">
  <div class="container-fluid">
    <a class="navbar-brand text-warning" href="index.php" style="font-weight: 800;">Wastee</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarTogglerDemo02">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="index.php" style="font-weight: 600;">Home</a>
        </li>
        
        <li class="nav-item">
          <a class="nav-link" aria-current="page" href="profile.php" style="font-weight: 600;">Profile</a>
        </li>

        <li class="nav-item">
          <a class="nav-link" aria-current="page" href="company.php" style="font-weight: 600;">Company</a>
        </li>
        

        
        <li class="nav-item">
      <?php if (access('ADMIN', false)){
        echo'<a class="nav-link " href="./admin/index.php" style="font-weight: 600;" style="font-weight: 600;">Admin Page</a>';
      } ?>
        </li>
      </ul>
      
      <?php
        if (!isset($_SESSION['myname'])){
          echo '<a class="nav-link btn btn-danger btn-sm text-light" href="logout.php">Login</a>';

        }else{
          echo "<span class='text-secondary px-3'>Username: </span>  " . $_SESSION['myname'];

          if (access('ADMIN', false)){
          echo '<a class="nav-link btn btn-secondary mx-2 btn-sm text-light" href="./admin/index.php">Admin Page</a>';
          }
          
          echo '<a class="nav-link btn btn-danger btn-sm text-light" href="logout.php">Logout</a>';
        }
        ?>
    </div>
  </div>
</nav>

















  <header class="top-page_header">
        <div class="hero text-dark">
            <h4>Welcome to</h4>
            <h1 class="name-0">Waste Management System </h1>
            <p class="content">
                Lorem ipsum dolor sit amet consectetur, adipisicing elit. Quibusdam, illum quaerat. Vitae nobis ab incidunt cupiditate sequi quis repudiandae velit.
            </p>
            
        </div>

    </header>
    <main class="content-main-sec">
        <!-- -------------------------- Right side navigation panel -->
        <div class="aside-nav-sec">
            <h1 class="aside-title">Notifications</h1>
            <ul class="row">
                
                <!-- ----------------- single buton sec-------- -->
                <li class="col col-md-2 col-lg-12 m-1">
                    <a href="events.php" type="button" class="btn btn-light button">One time Pick up</a>
                </li>
                
                <!-- ----------------- single buton sec-------- -->
                <li class="col col-md-2 col-lg-12 m-1">
                    <a href="events.php" type="button" class="btn btn-light button">Schedule a pickup</a>
                </li>
                
                <!-- ----------------- single buton sec-------- -->
                <li class="col col-md-2 col-lg-12 m-1">
                    <a href="Profile.php" type="button" class="btn btn-light button">My Profile</a>
                </li>
                
                <!-- ----------------- single buton sec-------- -->
                <li class="col col-md-2 col-lg-12 m-1">
                    <a href="events.php" type="button" class="btn btn-light button">Truck on duty</a>
                </li>
                
                <!-- ----------------- single buton sec-------- -->
                <li class="col col-md-2 col-lg-12 m-1">
                    <a href="#" type="button" class="btn btn-light button">My Payments</a>
                </li>
                
                <!-- ----------------- single buton sec-------- -->
                <li class="col col-md-2 col-lg-12 m-1">
                    <a href="events.php" type="button" class="btn btn-light button">
                        <img src="./assets/couple-1030744_1920.jpg" alt="" class="thumb" style="width:100px;">
                        <div class="description">
                            <h6>Truck on duty</h6>
                        </div>
                    </a>
                </li>
                
            </ul>
        </div>

        <!-- -------------------------- Main content -home sectin-side -->
        <section class="main-content-grids">
            <header class="top-page_header-pgs mx-auto">
                <!-- ------------------------nav bar needed here -->
    
                <!-- ------------------------nav bar needed here -->
                <p class="header-intros">
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Eveniet iste, assumenda, ratione natus obcaecati deserunt ducimus facere repudiandae veritatis reprehenderit quibusdam nihil commodi. Expedita incidunt blanditiis tempora magnam sapiente, quod adipisci. Ratione aut possimus vitae, earum fugit sed eum eligendi tenetur? Asperiores, ipsam voluptate saepe possimus pariatur officia, similique accusamus voluptatibus corrupti, repellat dolor? Repellat incidunt odit harum animi, autem nesciunt amet temporibus natus. Minima ex a nihil consequatur eum, qui ipsa officiis! Animi aspernatur quasi quaerat dolores a? Consequuntur atque nam repellat enim reiciendis aliquid voluptas? Quod reiciendis dolore ullam officiis debitis a eum doloribus, praesentium, sunt nemo ea?
                </p>

                <div class="container pickup-types">
                    <a href="#" type="button" class="btn btn-success button">One time Pick up</a>
                    <a href="subscription.php" type="button" class="btn btn-secondary button">Subscribe</a>
                </div>
            </header>
            <section class="container-group-tiles row">
                
                <!-- ----------------- single card -->
                <a href="events.php" type="button" class="btn button tile col col-xs-12 col-sm-12 col-lg-6">
                <!-- <div class="tile col col-sm-12 col-lg-6"> -->
                    <div class="container row">
                        
                        <img src="./assets/images/events.png" alt="" class="col" style="width:50px;">
                        <div class="col content">
                            <h5>Events & Schedules</h5>
                            <hr>
                            <p>
                            Dear our customer, seat back and be strong because we have got your back. Please click here and see what kind of service you we have on menu. We even have even more supprises, please try out.
                            </p>
                        </div>
                    </div>
                </a>
                
                <!-- ----------------- single card -->
                <div class="tile admin-consult col col-xs-12 col-sm-12 col-lg-6 p-2">
                    <h5>Report Missed Pickups</h5>
                            <hr>
                    <div class="container-form">
                        <form action="check-creds.php" method="post">
                            <input type="text" name="username" value="<?php echo $_SESSION['myname']?>" style="display: none;">
                            <input type="text" name="email" value="<?php echo $user['email'];?>" style="display: none;">
                            <input type="text" name="rank" value="<?php echo $user['rank'];?>" style="display: none;">
                            <textarea name="message" cols="30" rows="10" autocomplete="FALSE" placeholder="please type your message to the admin here..." required></textarea>
                            <button type="submit" class="btn-secondary p-2">Send <i class="fab fa-telegram-plane"></i></button>
                        </form>
                    </div>
                </div>
                
                <!-- ----------------- single card -->
                <a href="#" type="button" class="btn button tile col col-xs-12 col-sm-12 col-lg-6">
                <!-- <div class="tile col col-sm-12 col-lg-6"> -->
                    <div class="container row">
                        
                        <img src="./assets/images/payment.png" alt="" class="col" style="width:50px;">
                        <div class="col content">
                            <h5>Payment & Invoices</h5>
                            <hr>
                            <p>
                                If you have any queries of the Lorem ipsum dolor sit amet consectetur adipisicing elit. Distinctio, assumenda.
                            </p>
                        </div>
                    </div>
                </a>
                
                <!-- ----------------- single card -->
                <a href="#" type="button" class="btn button tile col col-xs-12 col-sm-12 col-lg-6">
                <!-- <div class="tile col col-sm-12 col-lg-6"> -->
                    <div class="container row">
                        
                        <img src="./assets/images/track_2.png" alt="" class="col" style="width:50px;">
                        <div class="col content">
                            <h5>View Service Requests</h5>
                            <hr>
                            <p>
                                If you have any queries of the Lorem ipsum dolor sit amet consectetur adipisicing elit. Distinctio, assumenda.
                            </p>
                        </div>
                    </div>
                </a>
            </section>
        </section>
    </main>






    <?php
require_once('./patials/footer.php')
?>