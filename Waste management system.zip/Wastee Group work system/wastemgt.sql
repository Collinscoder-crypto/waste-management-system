-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jul 12, 2021 at 09:05 AM
-- Server version: 5.7.31
-- PHP Version: 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `wastemgt`
--

-- --------------------------------------------------------

--
-- Table structure for table `adminquery`
--

DROP TABLE IF EXISTS `adminquery`;
CREATE TABLE IF NOT EXISTS `adminquery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `email` varchar(2000) NOT NULL,
  `rank` varchar(20) NOT NULL,
  `userid` bigint(20) NOT NULL,
  `message` varchar(60000) NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `adminquery`
--

INSERT INTO `adminquery` (`id`, `username`, `email`, `rank`, `userid`, `message`, `date`) VALUES
(3, 'John', 'john@gmail.com', 'user', 8085430200098, 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Eveniet iste, assumenda, ratione natus obcaecati deserunt ducimus facere repudiandae veritatis reprehenderit quibusdam nihil commodi. Expedita incidunt blanditiis tempora magnam sapiente, quod adipisci. Ratione aut possimus vitae, earum fugit sed eum eligendi tenetur? Asperiores, ipsam voluptate saepe possimus pariatur officia, similique accusamus voluptatibus corrupti, repellat dolor? Repellat incidunt odit harum animi, autem nesciunt amet temporibus natus. Minima ex a nihil consequatur eum, qui ipsa officiis! Animi aspernatur quasi quaerat dolores a? Consequuntur atque nam repellat enim reiciendis aliquid voluptas? Quod reiciendis dolore ullam officiis debitis a eum doloribus, praesentium, sunt nemo ea?', '2021-07-11 06:37:32'),
(2, 'mary', 'mary@keira.com', 'company', 41366670727660582, 'adipisicing elit. Eveniet iste, assumenda, ratione natus obcaecati deserunt ducimus facere repudiandae veritatis reprehenderit quibusdam nihil commodi. Expedita incidunt blanditiis tempora magnam sapiente, quod adipisci. Ratione aut possimus vitae, earum fugit sed eum eligendi tenetur? Asperiores, ipsam voluptate saepe possimus pariatur officia, similique accusamus voluptatibus corrupti, repellat dolor? Repellat incidunt odit harum animi, autem nesciunt amet temporibus natus. Minima ex a nihil consequatur eum, qui ipsa officiis! Animi aspernatur quasi quaerat dolores a? Consequuntur atque nam repellat enim reiciendis aliquid voluptas? Quod reiciendis dolore ullam officiis debitis a eum doloribus, praesentium, sunt nemo ea?', '2021-07-10 14:10:05'),
(4, 'John', 'john@gmail.com', 'user', 8085430200098, 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Eveniet iste, assumenda, ratione natus obcaecati deserunt ducimus facere repudiandae veritatis reprehenderit quibusdam nihil commodi. Expedita incidunt blanditiis tempora magnam sapiente, quod adipisci. Ratione aut possimus vitae, earum fugit sed eum eligendi tenetur? Asperiores, ipsam voluptate saepe possimus pariatur officia, similique accusamus voluptatibus corrupti, repellat dolor? Repellat incidunt odit harum animi, autem nesciunt amet temporibus natus. Minima ex a nihil consequatur eum, qui ipsa officiis! Animi aspernatur quasi quaerat dolores a? Consequuntur atque nam repellat enim reiciendis aliquid voluptas? Quod reiciendis dolore ullam officiis debitis a eum doloribus, praesentium, sunt nemo ea?', '2021-07-11 06:38:24'),
(5, 'Jamondo Mark', 'mark@gmail.com', 'user', 1925068116, 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Eveniet iste, assumenda, ratione natus obcaecati deserunt ducimus facere repudiandae veritatis reprehenderit quibusdam nihil commodi. Expedita incidunt blanditiis tempora magnam sapiente, quod adipisci. Ratione aut possimus vitae, earum fugit sed eum eligendi tenetur? Asperiores, ipsam voluptate saepe possimus pariatur officia, similique accusamus voluptatibus corrupti, repellat dolor? Repellat incidunt odit harum animi, autem nesciunt amet temporibus natus. Minima ex a nihil consequatur eum, qui ipsa officiis! Animi aspernatur quasi quaerat dolores a? Consequuntur atque nam repellat enim reiciendis aliquid voluptas? Quod reiciendis dolore ullam officiis debitis a eum doloribus, praesentium, sunt nemo ea?Lorem ipsum dolor sit amet consectetur adipisicing elit. Eveniet iste, assumenda, ratione natus obcaecati deserunt ducimus facere repudiandae veritatis reprehenderit quibusdam nihil commodi. Expedita incidunt blanditiis tempora magnam sapiente, quod adipisci. Ratione aut possimus vitae, earum fugit sed eum eligendi tenetur? Asperiores, ipsam voluptate saepe possimus pariatur officia, similique accusamus voluptatibus corrupti, repellat dolor? Repellat incidunt odit harum animi, autem nesciunt amet temporibus natus. Minima ex a nihil consequatur eum, qui ipsa officiis! Animi aspernatur quasi quaerat dolores a? Consequuntur atque nam repellat enim reiciendis aliquid voluptas? Quod reiciendis dolore ullam officiis debitis a eum doloribus, praesentium, sunt nemo ea?Lorem ipsum dolor sit amet consectetur adipisicing elit. Eveniet iste, assumenda, ratione natus obcaecati deserunt ducimus facere repudiandae veritatis reprehenderit quibusdam nihil commodi. Expedita incidunt blanditiis tempora magnam sapiente, quod adipisci. Ratione aut possimus vitae, earum fugit sed eum eligendi tenetur? Asperiores, ipsam voluptate saepe possimus pariatur officia, similique accusamus voluptatibus corrupti, repellat dolor? Repellat incidunt odit harum animi, autem nesciunt amet temporibus natus. Minima ex a nihil consequatur eum, qui ipsa officiis! Animi aspernatur quasi quaerat dolores a? Consequuntur atque nam repellat enim reiciendis aliquid voluptas? Quod reiciendis dolore ullam officiis debitis a eum doloribus, praesentium, sunt nemo ea?Lorem ipsum dolor sit amet consectetur adipisicing elit. Eveniet iste, assumenda, ratione natus obcaecati deserunt ducimus facere repudiandae veritatis reprehenderit quibusdam nihil commodi. Expedita incidunt blanditiis tempora magnam sapiente, quod adipisci. Ratione aut possimus vitae, earum fugit sed eum eligendi tenetur? Asperiores, ipsam voluptate saepe possimus pariatur officia, similique accusamus voluptatibus corrupti, repellat dolor? Repellat incidunt odit harum animi, autem nesciunt amet temporibus natus. Minima ex a nihil consequatur eum, qui ipsa officiis! Animi aspernatur quasi quaerat dolores a? Consequuntur atque nam repellat enim reiciendis aliquid voluptas? Quod reiciendis dolore ullam officiis debitis a eum doloribus, praesentium, sunt nemo ea?Lorem ipsum dolor sit amet consectetur adipisicing elit. Eveniet iste, assumenda, ratione natus obcaecati deserunt ducimus facere repudiandae veritatis reprehenderit quibusdam nihil commodi. Expedita incidunt blanditiis tempora magnam sapiente, quod adipisci. Ratione aut possimus vitae, earum fugit sed eum eligendi tenetur? Asperiores, ipsam voluptate saepe possimus pariatur officia, similique accusamus voluptatibus corrupti, repellat dolor? Repellat incidunt odit harum animi, autem nesciunt amet temporibus natus. Minima ex a nihil consequatur eum, qui ipsa officiis! Animi aspernatur quasi quaerat dolores a? Consequuntur atque nam repellat enim reiciendis aliquid voluptas? Quod reiciendis dolore ullam officiis debitis a eum doloribus, praesentium, sunt nemo ea?Lorem ipsum dolor sit amet consectetur adipisicing elit. Eveniet iste, assumenda, ratione natus obcaecati deserunt ducimus facere repudiandae veritatis reprehenderit quibusdam nihil commodi. Expedita incidunt blanditiis tempora magnam sapiente, quod adipisci. Ratione aut possimus vitae, earum fugit sed eum eligendi tenetur? Asperiores, ipsam voluptate saepe possimus pariatur officia, similique accusamus voluptatibus corrupti, repellat dolor? Repellat incidunt odit harum animi, autem nesciunt amet temporibus natus. Minima ex a nihil consequatur eum, qui ipsa officiis! Animi aspernatur quasi quaerat dolores a? Consequuntur atque nam repellat enim reiciendis aliquid voluptas? Quod reiciendis dolore ullam officiis debitis a eum doloribus, praesentium, sunt nemo ea?Lorem ipsum dolor sit amet consectetur adipisicing elit. Eveniet iste, assumenda, ratione natus obcaecati deserunt ducimus facere repudiandae veritatis reprehenderit quibusdam nihil commodi. Expedita incidunt blanditiis tempora magnam sapiente, quod adipisci. Ratione aut possimus vitae, earum fugit sed eum eligendi tenetur? Asperiores, ipsam voluptate saepe possimus pariatur officia, similique accusamus voluptatibus corrupti, repellat dolor? Repellat incidunt odit harum animi, autem nesciunt amet temporibus natus. Minima ex a nihil consequatur eum, qui ipsa officiis! Animi aspernatur quasi quaerat dolores a? Consequuntur atque nam repellat enim reiciendis aliquid voluptas? Quod reiciendis dolore ullam officiis debitis a eum doloribus, praesentium, sunt nemo ea?Lorem ipsum dolor sit amet consectetur adipisicing elit. Eveniet iste, assumenda, ratione natus obcaecati deserunt ducimus facere repudiandae veritatis reprehenderit quibusdam nihil commodi. Expedita incidunt blanditiis tempora magnam sapiente, quod adipisci. Ratione aut possimus vitae, earum fugit sed eum eligendi tenetur? Asperiores, ipsam voluptate saepe possimus pariatur officia, similique accusamus voluptatibus corrupti, repellat dolor? Repellat incidunt odit harum animi, autem nesciunt amet temporibus natus. Minima ex a nihil consequatur eum, qui ipsa officiis! Animi aspernatur quasi quaerat dolores a? Consequuntur atque nam repellat enim reiciendis aliquid voluptas? Quod reiciendis dolore ullam officiis debitis a eum doloribus, praesentium, sunt nemo ea?Lorem ipsum dolor sit amet consectetur adipisicing elit. Eveniet iste, assumenda, ratione natus obcaecati deserunt ducimus facere repudiandae veritatis reprehenderit quibusdam nihil commodi. Expedita incidunt blanditiis tempora magnam sapiente, quod adipisci. Ratione aut possimus vitae, earum fugit sed eum eligendi tenetur? Asperiores, ipsam voluptate saepe possimus pariatur officia, similique accusamus voluptatibus corrupti, repellat dolor? Repellat incidunt odit harum animi, autem nesciunt amet temporibus natus. Minima ex a nihil consequatur eum, qui ipsa officiis! Animi aspernatur quasi quaerat dolores a? Consequuntur atque nam repellat enim reiciendis aliquid voluptas? Quod reiciendis dolore ullam officiis debitis a eum doloribus, praesentium, sunt nemo ea?Lorem ipsum dolor sit amet consectetur adipisicing elit. Eveniet iste, assumenda, ratione natus obcaecati deserunt ducimus facere repudiandae veritatis reprehenderit quibusdam nihil commodi. Expedita incidunt blanditiis tempora magnam sapiente, quod adipisci. Ratione aut possimus vitae, earum fugit sed eum eligendi tenetur? Asperiores, ipsam voluptate saepe possimus pariatur officia, similique accusamus voluptatibus corrupti, repellat dolor? Repellat incidunt odit harum animi, autem nesciunt amet temporibus natus. Minima ex a nihil consequatur eum, qui ipsa officiis! Animi aspernatur quasi quaerat dolores a? Consequuntur atque nam repellat enim reiciendis aliquid voluptas? Quod reiciendis dolore ullam officiis debitis a eum doloribus, praesentium, sunt nemo ea?Lorem ipsum dolor sit amet consectetur adipisicing elit. Eveniet iste, assumenda, ratione natus obcaecati deserunt ducimus facere repudiandae veritatis reprehenderit quibusdam nihil commodi. Expedita incidunt blanditiis tempora magnam sapiente, quod adipisci. Ratione aut possimus vitae, earum fugit sed eum eligendi tenetur? Asperiores, ipsam voluptate saepe possimus pariatur officia, similique accusamus voluptatibus corrupti, repellat dolor? Repellat incidunt odit harum animi, autem nesciunt amet temporibus natus. Minima ex a nihil consequatur eum, qui ipsa officiis! Animi aspernatur quasi quaerat dolores a? Consequuntur atque nam repellat enim reiciendis aliquid voluptas? Quod reiciendis dolore ullam officiis debitis a eum doloribus, praesentium, sunt nemo ea?Lorem ipsum dolor sit amet consectetur adipisicing elit. Eveniet iste, assumenda, ratione natus obcaecati deserunt ducimus facere repudiandae veritatis reprehenderit quibusdam nihil commodi. Expedita incidunt blanditiis tempora magnam sapiente, quod adipisci. Ratione aut possimus vitae, earum fugit sed eum eligendi tenetur? Asperiores, ipsam voluptate saepe possimus pariatur officia, similique accusamus voluptatibus corrupti, repellat dolor? Repellat incidunt odit harum animi, autem nesciunt amet temporibus natus. Minima ex a nihil consequatur eum, qui ipsa officiis! Animi aspernatur quasi quaerat dolores a? Consequuntur atque nam repellat enim reiciendis aliquid voluptas? Quod reiciendis dolore ullam officiis debitis a eum doloribus, praesentium, sunt nemo ea?Lorem ipsum dolor sit amet consectetur adipisicing elit. Eveniet iste, assumenda, ratione natus obcaecati deserunt ducimus facere repudiandae veritatis reprehenderit quibusdam nihil commodi. Expedita incidunt blanditiis tempora magnam sapiente, quod adipisci. Ratione aut possimus vitae, earum fugit sed eum eligendi tenetur? Asperiores, ipsam voluptate saepe possimus pariatur officia, similique accusamus voluptatibus corrupti, repellat dolor? Repellat incidunt odit harum animi, autem nesciunt amet temporibus natus. Minima ex a nihil consequatur eum, qui ipsa officiis! Animi aspernatur quasi quaerat dolores a? Consequuntur atque nam repellat enim reiciendis aliquid voluptas? Quod reiciendis dolore ullam officiis debitis a eum doloribus, praesentium, sunt nemo ea?', '2021-07-11 07:18:49');

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

DROP TABLE IF EXISTS `events`;
CREATE TABLE IF NOT EXISTS `events` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `day` varchar(20) NOT NULL,
  `type` varchar(100) NOT NULL,
  `company` varchar(150) DEFAULT NULL,
  `price` varchar(20) DEFAULT NULL,
  `request` int(11) DEFAULT NULL,
  `created_date` datetime NOT NULL,
  `contact` varchar(25) DEFAULT NULL,
  `image` varchar(2048) DEFAULT NULL,
  `description` varchar(2000) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`id`, `day`, `type`, `company`, `price`, `request`, `created_date`, `contact`, `image`, `description`) VALUES
(2, '2021-07-09', 'Medical', 'KCCA', '5000', NULL, '2021-07-07 07:58:47', '+256-759680000', 'images/ivbvlEL4/RR_phantom_117_1920x1200.jpg', NULL),
(3, '2021-07-10', 'domestic', 'Wastedomest', '2500', NULL, '2021-07-07 08:22:51', '+256-7596845243', 'images/2OiGII7E/35.jpg', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Eveniet iste, assumenda, ratione natus obcaecati deserunt ducimus facere repudiandae veritatis reprehenderit quibusdam nihil commodi. Expedita incidunt blanditiis tempora magnam sapiente, quod adipisci. Ratione aut possimus vitae, earum fugit sed eum eligendi tenetur? Asperiores, ipsam voluptate saepe possimus pariatur officia, similique accusamus voluptatibus corrupti, repellat dolor? Repellat incidunt odit harum animi, autem nesciunt amet temporibus natus. Minima ex a nihil consequatur eum, qui ipsa officiis! Animi aspernatur quasi quaerat dolores a? Consequuntur atque nam repellat enim reiciendis aliquid voluptas? Quod reiciendis dolore ullam officiis debitis a eum doloribus, praesentium, sunt nemo ea?');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `rank` varchar(20) NOT NULL,
  `password` varchar(200) NOT NULL,
  `subscriber` varchar(10) DEFAULT NULL,
  `image` varchar(2048) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `date` (`date`),
  KEY `rank` (`rank`),
  KEY `email` (`email`),
  KEY `name` (`name`),
  KEY `name_2` (`name`),
  KEY `userid` (`userid`),
  KEY `subscriber` (`subscriber`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `userid`, `name`, `email`, `date`, `rank`, `password`, `subscriber`, `image`) VALUES
(5, 8085430200098, 'John', 'john@gmail.com', '2021-07-01 21:45:09', 'user', '8cb2237d0679ca88db6464eac60da96345513964', NULL, NULL),
(1, 9121160, 'Collins', 'colzadminumu@gmail.com', '2021-07-01 19:49:13', 'admin', '8cb2237d0679ca88db6464eac60da96345513964', NULL, NULL),
(2, 41366670727660582, 'mary', 'mary@keira.com', '2021-07-01 21:37:54', 'company', '7c4a8d09ca3762af61e59520943dc26494f8941b', NULL, NULL),
(6, 76925222734, 'Collins Mike', 'mike@gmail.com', '2021-07-02 18:48:44', 'user', '8cb2237d0679ca88db6464eac60da96345513964', NULL, NULL),
(7, 34929884230, 'John Doe', 'doe@gmail.com', '2021-07-09 09:27:50', 'user', '8cb2237d0679ca88db6464eac60da96345513964', NULL, NULL),
(8, 1925068116, 'Jamondo Mark', 'mark@gmail.com', '2021-07-11 10:16:19', 'user', '8cb2237d0679ca88db6464eac60da96345513964', NULL, NULL);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
