<?php
    $DB = new PDO("mysql:host=localhost;port=3306;dbname=wastemgt", 'root','');
    $DB->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);


$id = $_GET['id'] ?? null;

// echo '<pre>';
// var_dump($id);
// echo '</pre>';

if (!$id) {
    header('Location: index.php');
    // exit;
}

$statement = $pdo ->prepare('SELECT * FROM products WHERE id= :id');
$statement->bindValue(':id', $id);
$statement->execute();

$product = $statement->fetch(PDO::FETCH_ASSOC);

// echo '<pre>';
// var_dump($products);
// echo '</pre>';


function randomString($n){
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $str = '';

    for ($i = 0; $i < $n; $i++){
        $index = rand(0, strlen($characters)-1);
        $str .= $characters[$index];
    }

    return $str;
}

$errors = [];

$title = $product['title'];
$description = $product['description'];
$price = $product['price'];

if (!is_dir('images')) {
    mkdir('images');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST'){
    $title = $_POST['title'];
    $description = $_POST['description'];
    $price = $_POST['price'];

    if (!$title){
        $errors[] = 'Product title is required';
    }

    if (!$price){
        $errors[] = 'Product price is required';
    }
    
    if (empty($errors)) {

        $image = $_FILES['image'] ?? null;
        $imagePath = $product['image'];

        if ($image && $image['tmp_name']){
            $imagePath = 'images/'.randomString(8).'/'.$image['name'];
            
            if ($product['image']){
                unlink($product['image']);
            }

            mkdir(dirname($imagePath));
            move_uploaded_file($image['tmp_name'], $imagePath);
        }
        
        $statement = $pdo->prepare("UPDATE products SET title = :title, image = :image, description = :description, price = :price WHERE id = :id");
        
        $statement->bindValue(':title', $title);
        $statement->bindValue(':image', $imagePath);
        $statement->bindValue(':description', $description);
        $statement->bindValue(':price', $price);
        $statement->bindValue(':id', $id);
        
        $statement->execute();
        header('Location: index.php');
    }
    
}

?>



<!-- hide buttons from non users ================================ -->
<?php  
        // if (!isset($_SESSION['myname'])){
        //    echo '<a class="nav-link " href="./admin/index.php" style="font-weight: 600; display:none;" style="font-weight: 600;">Admin Page</a>';

        // }else{
        //     echo '<a class="nav-link " href="./admin/index.php" style="font-weight: 600; display:block;" style="font-weight: 600;">Admin Page</a>';
        // }
        ?>

