<?php
    $error = "";
    function create_userid() {
      $length = rand(4,20);
      $number = "";
      for ($i= 0; $i < $length; $i++) {
        $new_rand = rand(0,9);
        $number = $number . $new_rand;
      }
      return $number;
    }


if ($_SERVER['REQUEST_METHOD'] == "POST") {
      
      if (!$DB = new PDO("mysql:host=localhost;dbname=wastemgt","root","")){
        die("couldn't connect to the database");
      }

      $arr['userid'] = create_userid();
    //   $condition = true;

    //   while ($condition) {
    //     $query = "SELECT id FROM userid = :userid LIMIT 1";
    //     $stm = $DB->prepare($query);

    //     if ($stm){
    //       $check = $stm->execute($arr);
    //       if ($check){
    //         $data = $stm -> fetchAll(PDO::FETCH_ASSOC);

    //         if(is_array($data) && count($data) > 0){
    //           $arr['userid'] = create_userid();
    //           continue;
    //         }
    //       }

    //     }
    //     $condition = false;
    // }

      //save to DB
      $arr['name'] = $_POST['name'];
      $arr['email'] = $_POST['email'];
      $arr['password'] = hash('sha1', $_POST['password']);
      $arr['rank'] = "user";

      $query = "INSERT INTO users (userid,name,email,passord,rank) 
                VALUES ( :userid, :name, :email, :passord, :rank)";
        $stm = $DB->prepare($query);

        if ($stm) {
          $check = $stm -> execute($arr);

          if (!$check) {
            $error = "could not save to the database";
            // header("Location: signup.php");
          }

          if ($error == "") {
            header("Location: login.php");
            die;
          }
    }
    
}
