<?php 
session_start();
$pdo = new PDO('mysql:host=localhost;port=3306;dbname=products_crud', 'root', '');
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// echo "<pre>";
// var_dump($_SERVER);
// echo "</pre>";
// exit;

// echo "<pre>";
// var_dump($_POST);
// echo "</pre>";
// exit; 
// echo $_SERVER['REQUEST_METHOD'] . '<br>';

// echo "<pre>";
// var_dump($_FILES);
// echo "</pre>";


function randomString($n){
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $str = '';

    for ($i = 0; $i < $n; $i++){
        $index = rand(0, strlen($characters)-1);
        $str .= $characters[$index];
    }

    return $str;
}

$errors = [];

$title = '';
$description = '';
$price = '';

if (!is_dir('images')) {
    mkdir('images');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST'){
    $title = $_POST['title'];
    $description = $_POST['description'];
    $price = $_POST['price'];
    $date = date('Y-m-d H:i:s');

    if (!$title){
        $errors[] = 'Product title is required';
    }

    if (!$price){
        $errors[] = 'Product price is required';
    }
    
    if (empty($errors)) {

        $image = $_FILES['image'] ?? null;

        $imagePath = '';
        if ($image && $image['tmp_name']){
            $imagePath = 'images/'.randomString(8).'/'.$image['name'];

            mkdir(dirname($imagePath));
            move_uploaded_file($image['tmp_name'], $imagePath);
        }
        
        $statement = $pdo->prepare("INSERT INTO products (title, image, description, price, create_date)
                    VALUES (:title, :image, :description, :price, :date)");
        
        $statement->bindValue(':title', $title);
        $statement->bindValue(':image', $imagePath);
        $statement->bindValue(':description', $description);
        $statement->bindValue(':price', $price);
        $statement->bindValue(':date', $date);
        
        $statement->execute();
    }
    
}



?>









<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="./css/bootstrap.min.css">
    <link rel="stylesheet" href="./css/style.css">
    <style>
    body{
        background: url('./images/images/banner-ready1.png');
        background-size: cover;
    }
    form{
        width: 50%;
        position: relative;
        /* top: 50%;
        left: 50%;
        transform: translate(-50%, -50%); */
        padding: 10px;
    }
    form input:nth-child(2){
        background-color: whitesmoke;
        box-shadow: inset 0 0 10px black;
    }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top">
  <div class="container-fluid">
    <a class="navbar-brand text-warning" href="index.php">Wastee</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarTogglerDemo02">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="../index.php">View Page</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Link</a>
        </li>
        
        <li class="nav-item">
          <a class="nav-link" href="../users/index.php">Users</a>
        </li>
        <!-- <li class="nav-item">
          <a class="nav-link btn btn-danger btn-sm text-light" href="logout.php">Logout</a>
        </li> -->
      </ul>
      <h5 class="text-danger d-flex mx-2"><?php
        if (isset($_SESSION['myname'])){
          echo "<span class='text-secondary px-3'>Username: </span>  " . $_SESSION['myname'];
        }
        ?></span>
        <a class="nav-link btn btn-danger btn-sm text-light" href="../logout.php">Logout</a>
    </div>
  </div>
</nav>
    <h1 style="font-weight: 900;" class="my-5 text-light py-3">Create New User</h1>

        <button onclick="goBack()" class="btn btn-dark"><b> Back </b></button>

    <form action="" method="post" enctype="multipart/form-data" class="bg-light">

    <?php if (!empty($errors)): ?>

        <div class="alert alert-danger">
            <?php foreach ($errors as $error): ?>
            <p><?php echo $error; ?></p>
            <?php endforeach; ?>
        </div>

    <?php endif; ?>

        <div class="form-group">
            <label>Product image</label><br>
            <input type="file" name="image" class="bg-secondary">
        </div>
    
        <div class="form-group">
            <label>Product Title</label>
            <input type="text" name="title" class="form-control" value="<?php echo $title ?>">
        </div>
    
        <div class="form-group">
            <label>Product Description</label>
            <textarea class="form-control" name="description" value="<?php echo $description ?>"></textarea>
        </div>
    
        <div class="form-group">
            <label>Product Price</label>
            <input type="number" name="price" step=".01" class="form-control" value="<?php echo $price ?>">
        </div>
    
        <button type="submit" class="btn btn-primary">Submit</button>
</form> 
  
    <script src="./js/bootstrap.min.js"></script>
    <script>
    function goBack(){
        window.history.back();
    }
    </script>
</body>
</html>