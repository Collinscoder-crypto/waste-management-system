<?php 
$DB = new PDO("mysql:host=localhost;port=3306;dbname=wastemgt", 'root','');
$DB->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// echo '<pre>';
// var_dump($id);
// echo '</pre>';

$id = $_POST['id'] ?? null;
// echo '<pre>';
// var_dump($id);
// echo '</pre>';
// exit();

if (!$id) {
    header('Location: index.php');
    exit;
}

$statement = $DB->prepare("DELETE FROM users WHERE id=:id");
$statement->bindValue(':id', $id);
$statement->execute();

header('Location: index.php');

?>



<!-- 





<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="./css/bootstrap.min.css">
    <link rel="stylesheet" href="./css/style.css">
</head>
<body>
    <h1 style="font-weight: 900;">users Crud</h1>

    <p>
    <a href="create.php" class="btn btn-success">Create Product</a>
    </p>
  
    <script src="./js/bootstrap.min.js"></script>
</body>
</html> -->