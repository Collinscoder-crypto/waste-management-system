<?php 
$pdo = new PDO('mysql:host=localhost;port=3306;dbname=products_crud','root','');
$pdo -> setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);


$id = $_GET['id'] ?? null;

// echo '<pre>';
// var_dump($id);
// echo '</pre>';

if (!$id) {
    header('Location: index.php');
    // exit;
}

$statement = $pdo ->prepare('SELECT * FROM products WHERE id= :id');
$statement->bindValue(':id', $id);
$statement->execute();

$product = $statement->fetch(PDO::FETCH_ASSOC);

// echo '<pre>';
// var_dump($products);
// echo '</pre>';


function randomString($n){
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $str = '';

    for ($i = 0; $i < $n; $i++){
        $index = rand(0, strlen($characters)-1);
        $str .= $characters[$index];
    }

    return $str;
}

$errors = [];

$title = $product['title'];
$description = $product['description'];
$price = $product['price'];

if (!is_dir('images')) {
    mkdir('images');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST'){
    $title = $_POST['title'];
    $description = $_POST['description'];
    $price = $_POST['price'];

    if (!$title){
        $errors[] = 'Product title is required';
    }

    if (!$price){
        $errors[] = 'Product price is required';
    }
    
    if (empty($errors)) {

        $image = $_FILES['image'] ?? null;
        $imagePath = $product['image'];

        if ($image && $image['tmp_name']){
            $imagePath = 'images/'.randomString(8).'/'.$image['name'];
            
            if ($product['image']){
                unlink($product['image']);
            }

            mkdir(dirname($imagePath));
            move_uploaded_file($image['tmp_name'], $imagePath);
        }
        
        $statement = $pdo->prepare("UPDATE products SET title = :title, image = :image, description = :description, price = :price WHERE id = :id");
        
        $statement->bindValue(':title', $title);
        $statement->bindValue(':image', $imagePath);
        $statement->bindValue(':description', $description);
        $statement->bindValue(':price', $price);
        $statement->bindValue(':id', $id);
        
        $statement->execute();
        header('Location: index.php');
    }
    
}

?>





<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="./css/bootstrap.min.css">
    <link rel="stylesheet" href="./css/style.css">
    <style>
    form{
        width: 50%;
        position: relative;
        /* top: 50%;
        left: 50%;
        transform: translate(-50%, -50%); */
        background-color: wheat;
        padding: 10px;
    }

    input{
        font-weight: 600;
    }
    </style>
</head>
<body>
    <h1 style="font-weight: 900;" class="bg-primary">Update Product <span style="color: gold;"><?php echo $product['title']?></span></h1>

        <button onclick="goBack()" class="btn btn-outline-dark"><b> Back </b></button>

    <form action="" method="post" enctype="multipart/form-data">

        <?php if ($product['image']):?>
        <img src="<?php echo $product['image'] ?>" alt="" style="width: 120px; float: right;">
        <?php endif;?>

    <?php if (!empty($errors)): ?>

        <div class="alert alert-danger">
            <?php foreach ($errors as $error): ?>
            <p><?php echo $error; ?></p>
            <?php endforeach; ?>
        </div>

    <?php endif; ?>

        <div class="form-group">
            <label>Product image</label><br>
            <input type="file" name="image" value="<?php echo $product['image'] ?>">
        </div>
    
        <div class="form-group">
            <label>Product Title</label>
            <input type="text" name="title" class="form-control" value="<?php echo $title ?>">
        </div>
    
        <div class="form-group">
            <label>Product Description</label>
            <textarea class="form-control" name="description" value="<?php echo $description ?>"></textarea>
        </div>
    
        <div class="form-group">
            <label>Product Price</label>
            <input type="number" name="price" step=".01" class="form-control" value="<?php echo $price ?>">
        </div>
    
        <button type="submit" class="btn btn-primary">Submit</button>
</form> 
  
    <script src="./js/bootstrap.min.js"></script>
    <script>
    function goBack(){
        window.history.back();
    }
    </script>
</body>
</html>