<?php session_start(); ?>
<?php 
// $DB = new PDO('mysql:host=localhost;port=3306;dbname=users_crud','root','');
// $DB -> setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $DB = new PDO("mysql:host=localhost;port=3306;dbname=wastemgt", 'root','');
    $DB->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);



// --------------------------- search section ------------------
$search = $_GET['search'] ?? null;

if ($search){
  $statement = $DB->prepare('SELECT * FROM users WHERE name LIKE :name ORDER BY date DESC');
  $statement->bindValue(':name', "%$search%");
}else{
  $statement = $DB->prepare('SELECT * FROM users ORDER BY date DESC');
}

// --------------------------- search section ------------------




$statement -> execute();
$users = $statement -> fetchAll(PDO:: FETCH_ASSOC);

// echo '<pre>';
// var_dump($users);
// echo '</pre>';





?>
<?php
include ('./patials/header.php');
?>



<nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top">
  <div class="container-fluid">
    <a class="navbar-brand text-warning" href="index.php">Wastee</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarTogglerDemo02">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="../index.php">View Page</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Link</a>
        </li>
        
        <li class="nav-item">
          <a class="nav-link" href="../users/index.php">Users</a>
        </li>
        <!-- <li class="nav-item">
          <a class="nav-link btn btn-danger btn-sm text-light" href="logout.php">Logout</a>
        </li> -->
      </ul>
      <form action="" method="get" class="d-flex">
        <div class="input-group">
          <input type="search" class="form-control bg-info" placeholder="Search" name="search" value="<?php echo $search ?>">
          <div class="input-group-append">
            <button class="btn btn-success" type="submit">Search</button>
          </div>
      </div>
      </form>
      <h5 class="text-danger d-flex mx-2"><?php
        if (isset($_SESSION['myname'])){
          echo "<span class='text-secondary px-3'>Username: </span>  " . $_SESSION['myname'];
        }
        ?></span>
        <a class="nav-link btn btn-danger btn-sm text-light" href="../logout.php">Logout</a>
    </div>
  </div>
</nav>


    <h1 class="my-3" style="font-weight: 900;">Users</h1>

    <p>
    <a href="create.php" class="btn btn-success">Create new User</a>
    </p>

    <table class="table table-borderless">
    <thead>
      <tr>
        <th>#</th>
        <th>Image</th>
        <th>Username</th>
        <th>Email</th>
        <th>Create Date</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>

      <?php foreach ($users as $i => $user):?>
      <tr>
        <th scope="row"><?php echo $i +1; ?></th>
        <td><img src="<?php echo $user['image'] ?>" alt="product image" class="product-image-frm-db"></td>
        <td><?php echo $user['name'];?></td>
        <td><?php echo $user['email']?></td>
        <td><?php echo $user['date']?></td>
        <td>
        <div class="btn-group d-flex">
          <!-- <a href="update.php?id=<?php echo $user['id']?>" type="button" class="btn btn-primary">Edit</a> -->

          <form action="delete.php" method="post">
            <input type="hidden" name="id" value="<?php echo $user['id'] ?>">
            <button type="submit" class="btn btn-danger">Delete</button>
          </form>
      </div> 
        </td>
      </tr>
      <?php endforeach; ?>

    </tbody>
  </table>
  
    <script src="./js/bootstrap.min.js"></script>
</body>
</html>